import base64
from flask import Blueprint,request
from dotenv import load_dotenv
import os,json
load_dotenv()
from database import make_db_call


file_path = os.environ.get("QUERY_PATH") + "product.json"

try:
    if os.path.exists(file_path):
        with open(file_path,"r") as file:
            queries = json.load(file)
    else:
        print("your file is not exist")
except Exception as e:
    print("error occured ",str(e))


blueprint = Blueprint("trail",__name__)


