from flask import Blueprint,request,jsonify
from dotenv import load_dotenv
load_dotenv()
import os,json
from database import make_db_call
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, set_access_cookies, set_refresh_cookies, get_jwt_identity

blueprint = Blueprint("login",__name__)
file_path = os.environ.get('QUERY_PATH') + "users.json"

try:
    if os.path.exists(file_path):
        with open(file_path,'r') as file:
            queries = json.load(file)
    else:
        print('file is not exist')
except Exception as e:
    print(str(e))
        

@blueprint.route('/register',methods = ["POST"])
def register():
    if make_db_call(query=queries["get_user_email"],
                    type = "returns",
                    parameter = {"user_email":request.form["user_email"]})[0][0] == 1: 
        return "This email already exists. Please login"
    if make_db_call(query=queries["get_user_phone"],
                    type = "returns",
                    parameter = { "phone":request.form['phone']})[0][0] == 1: 
        return "This phone already exists. Please login"
    make_db_call(query=queries["register"],type='',parameter = {
        "username":request.form["username"],
        "user_email":request.form["user_email"],
        "password":request.form["password"],
        "phone":request.form['phone']
    })
    return "Register success"
  

@blueprint.route('/login', methods=['POST'])
def login():
    email = request.form['user_email']
    password = request.form['password']
    
    if make_db_call(query=queries['get_user_email'], type='returns', parameter={"user_email": email})[0][0] == 0:
        return 'This user is not registered. Please register first !', 404
    
    user_data = make_db_call(query=queries['login'], type='returns', parameter={"user_email": email, "password": password})
    
    data = make_db_call(query=queries['data'],type='returns',parameter={"user_email":email})
    if not user_data:
        return 'Invalid credentials', 401
    
    access_token = create_access_token(identity=email, fresh=True)
    refresh_token = create_refresh_token(identity=email)
    
    response =jsonify ({
        'access_token': access_token,
        "email":email,
        "username":data[0][0],
        "phone":data[0][3]
         })
    
    set_refresh_cookies(response, refresh_token)
    
    return response

@blueprint.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify(logged_in_as=current_user), 200

@blueprint.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    current_user = get_jwt_identity()
    access_token = create_access_token(identity=current_user, fresh=False)
    return jsonify(access_token=access_token)

@blueprint.route('/favourite',methods = ["POST"])
def favourite():
    make_db_call(query=queries["user_favourite"],type='',parameter = {
        "user_email":request.json["user_email"],
        "favourite":request.json["favourite"]
    })
    return "Done"