import base64
from flask import Blueprint,request,jsonify
from dotenv import load_dotenv
import os,json
load_dotenv()
from database import make_db_call


file_path = os.environ.get("QUERY_PATH") + "product.json"

try:
    if os.path.exists(file_path):
        with open(file_path,"r") as file:
            queries = json.load(file)
    else:
        print("your file is not exist")
except Exception as e:
    print("error occured ",str(e))


blueprint = Blueprint("product",__name__)

@blueprint.route("/get_all_product",methods = ["GET"])
def product():
    limit = int(request.args.get('rows_per_page'))
    offset = limit*(int(request.args.get('page')) - 1)
    search_term = request.args.get('search_term') + '%' if request.args.get('search_term') is not None else None
    search_by = request.args.get('search_by')
    filter = request.args.get('filter')
    data = [[None]]
    if not (search_by is None or search_term is None):
        if search_by in ('id', 'product_name', 'product_price'):
            data = make_db_call(query=queries['get_product'].replace("##where##", f"where {search_by} like %(search_term)s"), type='returns', parameter={'limit':limit, 'offset':offset, 'search_term':search_term})    
        else:
            return "invalid search by"
    elif filter == 'asc':
        data = make_db_call(query=queries['asc_order'].replace("order_by",'asc'), type='returns', parameter={'limit':limit, 'offset':offset})
    elif filter == 'desc':
        data = make_db_call(query=queries['asc_order'].replace("order_by",'desc'), type='returns', parameter={'limit':limit, 'offset':offset})
    elif filter == 'price':
        data = make_db_call(query=queries['price_order'], type='returns', parameter={'limit':limit, 'offset':offset})
    else:
        
        data = make_db_call(query=queries['get_product'].replace("##where##", ''), type='returns', parameter={'limit':limit, 'offset':offset})
    response = "no data found"
    total_count = make_db_call(query=queries['count'], type='returns', parameter={})[0][0]
    if data != [[None]]:
        response = {
            "total_count":total_count,
            "data": [{   
                "product_name":item[0],
                "product_price":item[2],
                "product_decs":item[1],
                "product_rating":item[3],
                "product_instock":item[4],
                "product_id":item[5],
                "review":item[6],
                "product_img":''
            } for item in data]
        }
        try:
            file_path = os.environ.get('IMG_PATH')
            for product in response['data']:
                file_path_with_name = os.path.join(file_path, product['product_name'], '0.jpg')
                if os.path.isfile(file_path_with_name):
                    with open(file_path_with_name, mode="rb") as file:
                        product['product_img'] = base64.b64encode(file.read()).decode('utf-8')
        except Exception as e:
            print(f"Error: {e}")
    return response

@blueprint.route('/one_product',methods = ["GET"])
def get_product():
    
    data = make_db_call(query=queries['search_product'], type='returns', parameter={'product_id':request.args.get('product_id')})
    review = make_db_call(query=queries['review'], type='returns', parameter={})
    review_store = []
    for item in review:
        dict = {
            "name":item[0],
            "date":item[1],
            "rating":item[2],
            "review":item[3]
        }
        review_store.append(dict)
    response = "no data found"
    if data != [[None]]:
        response = {
                "product_name":data[0][0],
                "product_decs":data[0][2],
                "product_price":data[0][1],
                "product_rating":data[0][3],
                "product_instock":data[0][4],
                "product_id":data[0][5],
                "review_count":data[0][6],
                "reviews":review_store,
                "product_img":[]
            }
                   
    else:
        return response
    full_path = os.path.join(os.environ.get("IMG_PATH"), data[0][0])
    try: 
        if os.path.exists(full_path):
            for filename in os.listdir(full_path):
                file_path = os.path.join(full_path, filename)
                if os.path.isfile(file_path):
                    with open(file_path, mode='rb') as file:
                        b = base64.b64encode(file.read()).decode('utf-8')
                        response['product_img'].append(b)
        else:
            print("no product name is exist")
    except Exception as e:
        return "error ocuured" 
    
    return response

@blueprint.route('/latest_product',methods = ['GET'])
def latest_product():
    data = make_db_call(query = queries['latest_product'],type = "returns",parameter = {})
    response = [
            {
                "product_name":item[0],
                "product_price":item[1],
                "product_decs":item[2],
                "product_rating":item[3],
                "product_instock":item[4],
                "product_img":''
            } for item in data
        ]
    try:
            file_path = os.environ.get('IMG_PATH')
            for product in response:
                file_path_with_name = os.path.join(file_path, product['product_name'], '0.jpg')
                if os.path.isfile(file_path_with_name):
                    with open(file_path_with_name, mode="rb") as file:
                        product['product_img'] = base64.b64encode(file.read()).decode('utf-8')
    except Exception as e:
            print(f"Error: {e}")
    return str(response)

@blueprint.route('/popular_product',methods=['GET'])
def popular_product():
    tables = [table[0] for table in make_db_call(query=queries['q1'],type='returns',parameter={})]
    

    for table in tables:
        q2 = queries['q2'].replace("##add##", queries['a'].replace("table1", str("order_details.\"")+table + "\""))
    q2 = q2.replace("UNION ALL ##add##", '')
    ans = make_db_call(q2, 'returns', parameter={})
    id = [id[0] for id in ans]
    
    data =  make_db_call(query=queries['see_all_product'],type = 'returns',parameter= {})
    store = []
    response = []
    for item in data:
        if item[0] in id:
            add = make_db_call(query=queries['find'],type = 'returns',parameter= {'product_id':item[0]})

            for item in add:
                store.append({
                    "product_id":item[0] ,
                    "product_name" : item[1],
                    "product_price":item[2],
                    "product_decs":item[3],
                    "product_rating":item[4],
                    "product_instock":item[5],
                    "product_img":""
                })
                response = store
            try:
                file_path = os.environ.get('IMG_PATH')
                for product in response:
                    file_path_with_name = os.path.join(file_path, product['product_name'], '0.jpg')
                    if os.path.isfile(file_path_with_name):
                        with open(file_path_with_name, mode="rb") as file:
                            product['product_img'] = base64.b64encode(file.read()).decode('utf-8')
            except Exception as e:
                print(f"Error: {e}")  
    if response:
        return response
    else:
        return  jsonify({
            "message":"no data found"
        })
    