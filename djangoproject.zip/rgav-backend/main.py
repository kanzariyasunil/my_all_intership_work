from flask import Flask,jsonify
from dotenv import load_dotenv
from flask_cors import CORS
from datetime import timedelta
from flask_jwt_extended import JWTManager

load_dotenv()
app = Flask(__name__)
CORS(app)

app.config["JWT_SECRET_KEY"] = "wfugwqfegyuoqwgfeuiowgqefo"  # Change this to a secret key of your choice
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=10)  # Adjust token expiration time as needed
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(hours=24)  # Adjust token expiration time as needed

jwt = JWTManager(app)

from blueprints.product import blueprint as product
from blueprints.users import blueprint as users
from blueprints.orders import blueprint as orders
from trail import blueprint as trail


app.register_blueprint(product)
app.register_blueprint(users)
app.register_blueprint(orders)    
app.register_blueprint(trail)

@jwt.expired_token_loader
def expaired_token_callback(jwt_headers, jwt_payload):
    return jsonify({
        "message": "The token has expired",
        "error": "token_expired"
    }), 401

@jwt.invalid_token_loader
def invalid_token_callback(error):
    return jsonify({
        "message": "The token is invalid ",
        "error": "invalid_token"
    }), 401

@jwt.unauthorized_loader
def unauthorized_callback(error):
    return jsonify({
        "message": "Request does not contain an access token",
        "error": "authorization_required"
    }), 401
    
@app.route("/")
def product():
    return "hii"
if __name__ == "__main__":
    app.run(debug = True, host="0.0.0.0", port=5000)