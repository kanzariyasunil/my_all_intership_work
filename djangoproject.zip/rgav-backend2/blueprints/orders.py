import datetime
from flask import Blueprint,request
from dotenv import load_dotenv
load_dotenv()
import os,json
from database import make_db_call, make_many_db_call


blueprint = Blueprint('orders',__name__)

file_path = os.environ.get('QUERY_PATH') + "orders.json"

try:
    if os.path.exists(file_path):
        with open(file_path,'r') as file:
            queries = json.load(file)
    else:
        print('file is not exists')
except:
    print('error occuerd file path')
   

@blueprint.route('/order',methods=['POST'])
def order(): 
    prod_instock = make_db_call(
        query = queries['check_instock'].replace('##id##',str('%s') + ', %s'*(len(request.json['product'])-1)),
        type='returns',parameter=[prod[0] for prod in request.json['product']])
    
    order_id = make_db_call(query= queries['insert_order'],
                                 type = 'returns',
                                 parameter = {
                                     "user_email":request.json['user_email'],
                                     "shipping_address":request.json['shipping_address'],
                                     "order_total":request.json['order_total'],
                                     "order_date":datetime.datetime.now(),
                                     "order_status":1,
                                     "order_tax":request.json['order_tax'],
                                     "coupon_code":request.json['coupon_code'],
                                     "discount":request.json['discount']
                                 }    )[0][0]
    make_db_call(query= queries['order_table'].replace('##name##',order_id),type = '',parameter={})
    
    data = make_many_db_call(query=queries['insert_order_table'].replace('##name##',order_id),type = 'returns',
                              parameter=request.json['product'])
    
    for i in range(len(prod_instock)):
        for j in range(len(data)):
            if prod_instock[i][0] == data[j][0]:
                if 0 < prod_instock[i][1] - data[j][1]:
                    diff = prod_instock[i][1] - data[j][1]
                    print(diff,data[i][0])
                    make_db_call(query=queries['update_product'],type='',parameter={"product_instock":diff,"product_id":prod_instock[i][0]})
                else:
                    return prod_instock[i][0] + "out of stock"
                
    return "done"

@blueprint.route('/check',methods=['GET'])
def check():
    instock = make_db_call(query = queries['check_instock'],type = 'returns',parameter = {})
 
    return str(instock)



# return prod_instock