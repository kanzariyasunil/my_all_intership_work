from flask import Blueprint,request
from dotenv import load_dotenv
load_dotenv()
import os,json
from database import make_db_call

blueprint = Blueprint("login",__name__)
file_path = os.environ.get('QUERY_PATH') + "users.json"

try:
    if os.path.exists(file_path):
        with open(file_path,'r') as file:
            queries = json.load(file)
    else:
        print('file is not exist')
except Exception as e:
    print(str(e))
        

@blueprint.route('/register',methods = ["POST"])
def register():
    if make_db_call(query=queries["get_user_count"],
                    type = "returns",
                    parameter = {"user_email":request.form["user_email"]})[0][0] == 1: 
        return "This email already exists. Please login"
    make_db_call(query=queries["register"],type='',parameter = {
        "username":request.form["username"],
        "user_email":request.form["user_email"],
        "password":request.form["password"],
        "phone":request.form['phone']
    })
    return "Register success"
  

@blueprint.route("/login",methods = ["POST"])
def login():
    if make_db_call(query=queries["get_user_count"],
                    type = "returns",
                    parameter = {"user_email":request.form["user_email"]})[0][0] == 0: 
        return "This email is not registered. Please register"
    else:
        if make_db_call(query=queries["login"],
                        type = "returns",
                        parameter = {"user_email":request.form["user_email"],"password":request.form["password"]})[0][0] == 1:
            return "Login success"
        else:
            return "Wrong password"

@blueprint.route('/favourite',methods = ["POST"])
def favourite():
    make_db_call(query=queries["user_favourite"],type='',parameter = {
        "user_email":request.json["user_email"],
        "favourite":request.json["favourite"]
    })
    return "Done"