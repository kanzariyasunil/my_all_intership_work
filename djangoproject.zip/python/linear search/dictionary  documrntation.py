dict = {'a':'this is a' , 'b':'this is b'}
# content access 
print(dict.keys()) # get all keys 
print(dict.values()) # get all values
print(dict.items()) # get all items
print(dict.get('a')) # get key values

# adding element
d = {'d':'this is d'}
dict.update(d)
e = {'e':'this is e'}
dict.update(e)
print(dict)

# remove elelment
dict.pop('e')
print(dict)