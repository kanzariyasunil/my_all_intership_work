def ternary(collection,key):
    last = 0
    first = len(collection) - 1
    while last <= first:
        mid1 = last + (first -  last) // 3
        mid2 = first - (first - last) // 3
        
        if collection[mid1] == key or collection[mid2] == key:
            print('value found')
        if collection[mid1] < key or collection[mid2] > key:
            last = mid1 + 1
            first = mid2 - 1
        if collection[mid1] > key:
            first = mid1 - 1
        if collection[mid2] < key:
            last = mid2 + 1
    return 'value not found'
a = [10,20,40,50,70,90,100]
key = 80
ternary(a,key)

