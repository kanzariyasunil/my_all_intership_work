a = [1,3,2,4,2,2,5,6,2,7]
a.append(2) # append one element in list at last Equivalent to a[len(a):] = x
print(a)

# append two or more item in list then use wxtend keyword , Equivalent a[len(a):] = iterable
a.extend([8,9,10])
print(a)

# insert is use to insert the with given position 
a.insert(1,20)
print(a)

# remove 
a.remove(2)
print(a)

# pop it remove the item given position other wise last element is remove
print(a.pop(4))
print(a)

# Return zero-based index in the list of the first item whose value is equal to x.
print(a.index(4))

# count
print(a.count(2))

# reverse
a.reverse()
print(a)

# copy()
b = a.copy()
print(b)
b = a

# sort list
a.sort(reverse = True)