a = [0, -1, 2, -3, 1]
for i in a:
    for j in a[1:]:
        for c in a[2:]:
            if i+j+c == 0:
                print(i,j,c,'sum of 0')