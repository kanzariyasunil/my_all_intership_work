a = [8, 3, 1, 2]
a_sum = sum(a)
value = [0]
for idx, i in enumerate(a):
    value[0] += i * idx
for i in a[:-1]:
    print(value)
    value.append(value[-1] - a_sum + i*len(a))
print(value)
print(max(value))