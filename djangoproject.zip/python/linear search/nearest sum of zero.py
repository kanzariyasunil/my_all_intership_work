ls =  [-65,-13,-14,-2,-1, 75]
left = 0
right = len(ls) - 1
ans = ls[right]+ls[left]
while left < right:
    if abs(ls[right]+ls[left]) < abs(ans):
        ans = ls[right]+ls[left]  
        if ans == 0:
            break
    elif ls[right]+ls[left] > 0:
        right -= 1
    else:
        left += 1
print(ans)