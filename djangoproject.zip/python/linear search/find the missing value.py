def repeat(ls,n):
    for i in range(n):
        for j in range(i+1,n):
            if ls[i] == ls[j]:
                return ls[i]
    return - 1
a = [2,4,5,7,8,5,3,1]
n = len(a)
print(repeat(a,n))

