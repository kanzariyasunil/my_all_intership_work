a = 'ab+'
ans = []
ans1 = ''
for i in a:
    if i == '+' or i == '*' or i == '-' or i == '/':
        ans1 = i
    else:
        ans.append(i)
ans = [ans1,ans[0],ans[1]]
print(ans)