def largest(ls):
    ans = sorted(ls[:3])
    print(ans)
    for i in ls:
        if i > ans[2]:
            ans = [ans[1],ans[2],i]
        elif i > ans[1]:
            ans = [ans[1],i,ans[2]]
        elif i >ans[0]:
            ans = [i,ans[1],ans[2]]
    print(ans)
    
a = [5,2,4,1,6,9,10,7,10,4,10,8]
largest(a)
           
           
           