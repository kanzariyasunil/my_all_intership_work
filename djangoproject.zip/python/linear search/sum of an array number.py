a=[1, 2, 3, 6, 3, 6, 1]
d = {}
for i in a:
    try:
        d[i] += 1
    except:
        d[i] = 1

for i in d:
    if d[i] >= 2:
        print(i)