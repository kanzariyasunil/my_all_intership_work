arr = [3, 1, 2, 2, 1, 2, 3, 3]
k = 4
d = {}
ans = []
for i in arr:
    try:
        d[i] += 1
    except:
        d[i] = 1
for i in d:
    if d[i] > len(arr)//k:
        ans.append(i)
print(ans)
