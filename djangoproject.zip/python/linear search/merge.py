from heapq import merge
a = [1,2,3,4,5]
b = [2,4,5,6,1]
print(list(merge(a,b)))