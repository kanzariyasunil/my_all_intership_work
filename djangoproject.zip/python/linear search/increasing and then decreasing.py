arr = [8, 10, 20, 80, 100, 200, 400, 500, 3, 2, 1]
c = arr[0]
for i in arr:
    if c < i:
        c = i
print(c)

arr1 = [120, 100, 80, 20, 0]
b = arr1[0]
for i in arr1:
    if b < i:
        b = i
print(b) 