test_str = 'gfg is best for geeks'
print(test_str)
t = test_str.split()
re = ''
test_dict = {'geeks': 1, 'best': 6}
for key in t:
    if key in test_dict.keys():
        test_str = test_str.replace(key,' ')
print(test_str)

temp = test_str.split(' ')
temp1 = [word for word in temp if word.lower() not in test_dict]
print(temp1)
res = ' '.join(temp1)
 
# Printing result
print("The string after replace : " + str(res))