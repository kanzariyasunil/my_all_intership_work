# k = ' Python is great and Java is also great'
# j = k.split()
# d = []
# for i in j:
#     if i not in d:
#         d.append(i)
# print(d)

k = "Python is great and Java is also great"
j = k.split()
d = []
for i in j:
    if i not in d:
        d.append(i)
print(d)