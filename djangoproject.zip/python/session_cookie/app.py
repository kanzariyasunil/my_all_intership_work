from flask import Flask,render_template,session,flash,request
app = Flask(__name__,template_folder='templates')
app.secret_key = 'c89f7f127a2d9426f969bfb251b1d15e'

@app.route('/')
def index():
    return render_template('index.html',message = "index page")


@app.route('/set_data')
def set_data():
    session['name'] = 'bala'
    session['other'] = 123
    return render_template('index.html',message='session page')
    
@app.route('/get_data')
def get_data():
    if 'name' in session.keys() and 'other' in session.keys():
        name = session['name']
        other = session['other']
        return render_template('index.html',message = f"name is {name} and other is {other}")
    else:
        return render_template('index.html',massege = "session not found")
    
@app.route('/clear')
def clear_session():
    session.clear()
    return render_template('index.html',message = "session cleared")

@app.route('/login',methods = ["POST","GET"])
def login():
    if request.method == "GET":
        return render_template('index.html')
    elif request.method == "POST":
        username = request.form.get('username')
        password = request.form.get('password')
        if username == 'bala' and password == '123':
            flash('login success')
            return render_template('index.html',message = "login success")
    else:
        return 'something went wrong'
    

if __name__ == "__main__":
    app.run(debug = True)
    