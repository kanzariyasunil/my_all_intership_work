s = "GeeksforGeeks"
d = 2
j = s[d:] + s[0:d]
print(j)
p = s[-d:]+s[:-d]
print(p)
print(s[-d:])