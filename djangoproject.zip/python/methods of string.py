# there are many methods of strings 
# title method convert first lettes into upper case and other into lower case

s = 'tHIS A NEw title for teaCH ous '
print(s.title())
# you can olso write a code 
s = 'this is a new code for now '.title()
print(s)
# capitilaize function
print(s.capitalize())
k = '-'.join(s)
print(k)
k = '* '.join(k)
print(k)
k = k.split()

t = "12,334,34.47"
print(t)
t = t.replace(',','third')
print(t)
t = t.replace('.',',')
print(t)
t = t.replace('third','.')
print(t)
x = t + 'hii'
