def chack_vow(st,vowel):
    f = [each for each in st if each in vowel]
    print(len(f))
    return f
f = 'hii this is a innovation compny'
vowel = 'aAeEiIoOuU'
chack_vow(f,vowel)

m = 'the mission complete the course'
j = [k for k in m if k in vowel]
print(len(j),',',j)

# this is like any other charecter fach 
a = '!@#$%^*()'
b = 'this @ to convert^ * ( fing )'
k = [i for i in b if i in a]
print(type(k))
print(type(str(k)))
print(''.join(k))
h = ['hii,ff-d&,]fj8j84']
print('-'.join(h))
j= '*'.join(a)
n= list(a)
z = "@".join(n)
print(n)
