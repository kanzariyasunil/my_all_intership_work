a = [58,56,2,4,5,6,45,67,3,2,6,45,10,7,8,9,45,7,54,23,12,10]
b = a[:1]
c = a[-1:]
d = c+ a[1:len(a) - 1]+  b
print(d)

# and other way is

def ch(l):
    l[0] , l[-1] = l[-1] , l[0]
    print(l)
ch(a)
d = 'hii this computer'

# swap the two elements
a = [1,2,4,5,6,7,8,9]
s = 4 
s1 = 7
a[4] ,a[7] = a[7] ,a[4]
print(a)

# swap  the element of the string 
# Python3 code to demonstrate 
# Swap elements in String list
# using replace() + join() + split()

# Initializing list
test_list = ['Gfg', 'is', 'best', 'for', 'Geeks']
t = '.'.join(test_list)
# printing original lists
print("The original list is : " + str(test_list))

# Swap elements in String list
# using replace() + join() + split()
res = ", ".join(test_list)
print('res',res)
res = res.replace("G", "_").replace("e", "G").replace("_", "e").split(', ')

# printing result 
print ("List after performing character swaps : " + str(res))

