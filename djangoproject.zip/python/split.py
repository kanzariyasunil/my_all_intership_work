a = 'hii , why are you  - stay , here'
print(a.split('-'))
print(' ,-" '.join(a))
sk = 'hii this - is - very well - - - try to learn do ewell now this '
# this bellow part divide in 3 part were first tree '-'  is  appear
print(sk.split('-',3))

