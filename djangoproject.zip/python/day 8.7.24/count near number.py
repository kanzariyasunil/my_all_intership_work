# s = 'geekksforgggeeks'
# def check(string):
#     cnt = 1
#     c = 1 
#     en = 2
#     l = []
#     for i in string:
#         j = string[c:en]
#         if i == j:
#             cnt += 1
#         else:
#             l.append(cnt)
#             cnt = 1
#         c += 1
#         en += 1
    
#     print(l,sum(l),len(string))
# check(s)
# r = 'rrrrkkkddddeeeuuuu'
# check(r)
# r = 'aaa'
# check(r)
# r = 'a'
# check(r)



def two(s):
    c = 1
    ans = []
    prev = s[0]
    for i in s[1:]:
        if i == prev:
            c += 1
        else:
           ans.append(c)
           c=1
        prev = i
    ans.append(c)
    return ans

print(two('rrrrkkkddddeeeuuuu'))

def three(s):
    l = 0
    r = 1
    ans = []
    while r < len(s):
        if s[r]!=s[l]:
            ans.append(r-l)
            l=r
        r+=1
    ans.append(r-l)
    return ans
print("passed" if three('rrrrkkkddddeeeuuuu')==[4, 3, 4, 3, 4] else "failed")
print(two('r')==[1])

