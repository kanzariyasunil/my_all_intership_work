d = {}
print(d)
d['a'] = 1
print(d)
d['a'] += 3
print(d)
d['b'] = 1
print(d)
del d['a']
print(d)
print(d['b'])
try:
    print(d['a'])
except:
    print('coundt find a')
    
e = {}
e[1] = 10
print(e)
e[str([1,2])] =20
print(e)
e[2.5]  = 34
print(e)


