# import re 
# def extract(input):
#     num = re.findall('\d+',input)
#     num = map(int,num)
#     print(max(num))
# a= '100klh564abc365bg'
# extract(a)

import re
put = '100klh564abc365bg'
num  = re.findall('\d+',put)
num = map(int,num)
print(max(num))