with open("P:/q2.txt", 'r') as file:
    print(file.read())