from flask import Flask,request,jsonify
app = Flask(__name__)

student = [
    {"id":1,
     "name":"ayush",
     "age":23},
    {"id":2,
     "name":"deo",
     "age":24},
    {"id":3,
     "name":"ayu",
     "age":23},
    {"id":4,
     "name":"yash",
     "age":20},
    {"id":5,
     "name":"haedik",
     "age":22}
]

@app.route('/')
def home():
    print('hiii')
    return '<h1>hiii</h1>'

@app.route('/stud',methods = ["GET"])
def stud():
    if request.method == "GET":
        return jsonify(student)

@app.route('/stud/<int:id>',methods = ["GET"])
def stud1(id):
    for i in student:
        if i['id'] == id:
            return i
    return "error"

@app.route('/stud',methods = ["POST"])
def add():
    new = {
        "id":request.form['id'],
        "name":request.form['name'],
        "age":request.form['age']
    }
    student.append(new)
    return new

@app.route('/stud/<int:stud_id>',methods=["PUT"])
def update(stud_id):
    for st in student:
        if st["id"] == stud_id:
            st['name'] = request.form['name']
            st['age']  = request.form['age']
            return 'your data has been successful added'
    return 'not right id you can search'

@app.route('/stud/<int:stud_id>',methods=["DELETE"])
def delete(stud_id):
    for st in student:
        if st["id"] == stud_id:
            student.remove(st)
            return 'your data has been successful deleted'
    return 'not right id you can search'

if __name__=="__main__":
    app.run(debug=True)