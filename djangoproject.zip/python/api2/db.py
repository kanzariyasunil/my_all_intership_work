import sqlite3

conn = sqlite3.connect("school.sqlite")
cursor = conn.cursor()

sql_query = """
create table sch(
    id integer PRIMATY KEY,
    name varchar(20) not null,
    age integer not null
)
"""

cursor.execute(sql_query)