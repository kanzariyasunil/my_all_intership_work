from flask import Flask,request,jsonify
import sqlite3
app = Flask(__name__)

def db_connection():
    conn = None
    try:
        conn = sqlite3.connect('school.sqlite')
    except sqlite3.Error as e:
        print(e)
    return conn

      


@app.route('/')
def home():
    return 'hiii'

@app.route('/stud',methods = ["GET"])
def stud():
    if request.method == "GET":
        conn = db_connection()  
        cursor = conn.cursor() 
        cursor.execute("select * from sch")
        book = [dict(id = row[0],name = row[1],age=row[2])
                for row in cursor.fetchall()
                ]
        if book is not None:
            return jsonify(book)


@app.route('/stud',methods = ["POST"])
def add():
    conn = db_connection()  
    cursor = conn.cursor()
    id = request.form['id']
    name = request.form['name']
    age = request.form['age']
    sql = """ insert into sch(id,name,age) values (?,?,?)
    """
    cursor.execute(sql,[id,name,age])
    conn.commit()
    return "Success"
    
@app.route('/stud/<int:id>',methods=["PUT"])
def update(id):
    conn = db_connection()
    cursor = conn.cursor()
    sql = """  update sch set name = ?,age = ? where id = ? """
    name = request.form['name']
    age = request.form['age']
    cursor.execute(sql,(name,age,id))
    conn.commit()
    return "update successful"

@app.route('/stud/<int:id>',methods=["DELETE"])
def delete(id):
    conn = db_connection()
    cursor = conn.cursor()
    sql = """ delete from sch where id = ?"""
    cursor.execute(sql,(id,))
    conn.commit()
    return "delete successful"

# @app.route('/stud/<int:id>',methods = ["GET"])
# def stud1(id):
#     for i in student:
#         if i['id'] == id:
#             return i
#     return "error"


if __name__=="__main__":
    app.run(debug=True)