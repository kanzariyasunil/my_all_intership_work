# from collections import Counter
# def firstreapeat(input):
#     words = input.split(" ")
#     dict = Counter(words)
#     for key in words:
#         if dict [key] > 1:
#             print(key)
#             return
# if __name__ == '__main__':
#     input = 'ravi had a one bycle and one other '
#     firstreapeat(input)

def repeat(input):
    word = input.split()
    repeatnot = []
    re = []
    for i in word:
        if i not in repeatnot:
            repeatnot.append(i)
        else:
            re.append(i)
            print(re)
            break

input = 'ravi had a one bycle ravi and one other '
repeat(input)
