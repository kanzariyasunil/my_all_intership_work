nums = [1,12,-5,-6,50,3]
k = 4
left = 0
ans = []
ans1 = 0
right = len(nums) - 1
while left < right:
    if left < k:
       ans1 += nums[left] 
    left += 1
ans.append(ans1)
left = 0
k = 4
while left < right:
    if left < k:
        ans1 = ans1 + nums[k] - nums[left]
        ans.append(ans1)
    print(max(ans)/k)
    k += 1
    left += 1
print(max(ans)/k)    

