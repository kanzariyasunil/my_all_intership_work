def power(number):
    temp = number
    if number < 2:
        return 'this is invalid case'
    while temp >=2:
        if temp == 2:
            return f'this number {number} is a pwoer of two'
        elif temp % 2 != 0:
            return f'this number {number} is not  power of two'
        else:
            temp  = temp // 2
            
number = 32
print(power(number))
