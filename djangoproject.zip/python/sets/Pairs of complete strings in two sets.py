set1 = {"abcdefgh", "geeksforgeeks",
                 "lmnopqrst", "abc"}
set2 = {"ijklmnopqrstuvwxyz", 
                 "abcdefghijklmnopqrstuvwxyz", 
                 "defghijklmnopqrstuvwxyz"}
count = 0
for i in set1:
    for j in set2:
        result = i + j
        tmset = set([ch for ch in result if (ord(ch) >= ord('a') and ord(ch) <= ord('z'))])
        if len(tmset) == 26:
            count += 1
print(count)
    