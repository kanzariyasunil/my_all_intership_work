t = "12,334,34.47"
def replace(st1):
    mt = st1.maketrans
    final = st1.translate(mt(',.','.,',' '))
    return final.replace(',',",") 
print(replace(t))
t = t.maketrans(t)
print(t)