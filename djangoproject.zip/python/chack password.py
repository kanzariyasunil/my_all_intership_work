# def chack(pa , no):
#     pa = str(pa)
#     no = str(no)
#     if len(no) == 8:
#         if pa == no:
#             print('this is correct password')
#         else:
#             print('this is not correct passwod')
#     else:
#         print('your password len sort or long')
# pa = 12345678
# no = 12345678
# chack(pa,no)
# if pa == no:
#     print('yes')

l ,u , d , p = 0,0,0,0
s = 'dcth@d_s12'

    
if (len(s) >= 8):
    for i in s:
        if(i.islower()):
            l += 1
            print(i,l)
        if(i.isupper()):
            u += 1
        if(i.isdigit()):
            d += 1
            print('this is digit \n',i,d)
        if (i == '@' or i == '_' or i=='$'):
            p +=1 
            print('this is speiacl chareter \n',p)
print(l ,u , d , p)
if(l>=1 and u>=1 and d>=1 and p>=1 and len(s) == l+u+d+p):
    print('your answer is coorect')
else:
    print('your answer is not correct')

# l, u, p, d = 0, 0, 0, 0
# s = "R@m@_f0rtu9e$"
# if (len(s) >= 8):
#     for i in s:
 
#         # counting lowercase alphabets 
#         if (i.islower()):
#             l+=1           
 
#         # counting uppercase alphabets
#         if (i.isupper()):
#             u+=1           
 
#         # counting digits
#         if (i.isdigit()):
#             d+=1           
 
#         # counting the mentioned special characters
#         if(i=='@'or i=='$' or i=='_'):
#             p+=1          
# if (l>=1 and u>=1 and p>=1 and d>=1 and l+p+u+d==len(s)):
#     print("Valid Password")
# else:
#     print("Invalid Password")