arr = ['geekforgeeks','gees','geeks']
a = 'geek'
b = []
for i in arr:
    if a in i:
        b.append(i)
print(b)            
