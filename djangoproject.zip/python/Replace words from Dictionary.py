test_str = 'geekforgeeks best for geeks'
t = test_str.replace('geeks','all the best')
print(t)
t  = test_str.split(' ')
print(t)
print(t[::-1])
print(t[-3:])