from datetime import datetime
from flask import Flask,render_template,url_for,flash,redirect
from flask_sqlalchemy import SQLAlchemy
from form import RegistrationForm,LoginForm
app = Flask(__name__)
app.config['SECRET_KEY'] = 'c89f7f127a2d9426f969bfb251b1d15e'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer,primary_key = True)
    username = db.Column(db.String(20),unique=True,nullable = False)
    email = db.Column(db.String(20),unique=True,nullable = False)
    # image_file = db.Column(db.String(20),unique=True,nullable=False,defaulr = 'default.jpg')
    password =db.Column(db.String(20),unique = True,nullable = False)
    posts = db.relationship('Post',backref = 'director',lazy =True)
    def __repr__(self):
        return f"User('{self.id}','{self.username}','{self.email}','{self.password}')"


class Post(db.Model):
    id = db.Column(db.Integer,primary_key = True)
    title = db.Column(db.String(20),nullable = False)
    date_posted = db.Column(db.DateTime,nullable = False,default = datetime.utcnow)
    content = db.Column(db.Text,nullable = False)
    user_id= db.Column(db.Integer,db.ForeignKey('user.id'),nullable = False)
    def __repr__(self):
        return f"Post('{self.title}','{self.date_posted}')" 
    
    
posts = [
    {
        'author':'corey',
        'title':'blog 1',
        'content':'flsk post',
        'date_posted':'april 20 22'
    },
    {
        'author':'campusx',
        'title':'blog 2',
        'content':'data scince post',
        'date_posted':'may 22 22'
    }, 
    {
        'author':'titanic',
        'title':'none',
        'content':'old post',
        'date_posted':'april 1 1999'
    }
    
]

@app.route('/')
def home():
    return render_template('home.html',posts = posts)

@app.route('/register',methods = ['GET','POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f' account will be created {form.username.data}!','success')
        return redirect(url_for('home'))
    return render_template('register.html',title = 'register',form=form)

@app.route('/login')
def login():
    form = LoginForm()
    return render_template('login.html',title = 'login',form = form)

if __name__ == '__main__':
    with app.app_context():
        print(User.query.all())
    # app.run(debug=True)