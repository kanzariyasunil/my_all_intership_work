from flask import Flask,render_template,url_for,flash,redirect
from form import RegistrationForm,LoginForm
app = Flask(__name__)
app.config['SECRET_KEY'] = 'c89f7f127a2d9426f969bfb251b1d15e'

posts = [
    {
        'movie':'bahubali',
        'direcor':'raj mauli'
    },
    {
        'movie':'bahubali2',
        'direcor':'raj mauli'
    }, 
    {
        'movie':'3 ideot',
        'direcor':'xyz'
    }
    
]

@app.route('/')
def home():
    return render_template('home.html',posts = posts)

@app.route('/register',methods = ['GET','POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f' account will be created {form.username.data}!','success')
        return redirect(url_for('home'))
    return render_template('register.html',title = 'register',form=form)

@app.route('/login')
def login():
    form = LoginForm()
    return render_template('login.html',title = 'login',form = form)

if __name__ == '__main__':
    app.run(debug=True)