from flask import request,jsonify,Blueprint
import mysql.connector
blueprint = Blueprint('product',__name__)

mysql = mysql.connector.connect(user ='root',password = "",host = "localhost",database = "ayurvedik")

cur = mysql.cursor()

@blueprint.route("/product_man",methods = ['GET'])
def product_man():
    cur.execute('select * from product_man')
    data = cur.fetchall()
    cur.close()
    return str(data)

@blueprint.route("/product_add",methods = ['POST'])
def product_add():
    cur.execute("insert into product_man (product_id,product_name,product_price) values (%(product_id)s,%(product_name)s,%(product_price)s)",{"product_id":request.form['product_id'],"product_name":request.form['product_name'],"product_price":request.form['product_price']})
    mysql.commit()
    cur.close()
    return "new product will add "

@blueprint.route("/product_update/<int:id>",methods=["PUT"])
def product_update(id):
    cur.execute('update product_man set product_name = %(product_name)s,product_price = %(product_price)s where product_id = %(id)s',{"id":id,"product_name":request.form['product_name'],"product_price":request.form['product_price']})
    mysql.commit()
    cur.close()
    return 'product will be updated '

@blueprint.route("/product_delete/<int:id>",methods = ["DELETE"])
def product_delete(id):
    cur.execute('delete from product_man where product_id = %(id)s',{"id":id})
    mysql.commit()
    cur.close()
    return "deleted successfully one row"