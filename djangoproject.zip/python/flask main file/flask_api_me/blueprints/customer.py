from flask import request,Blueprint
import mysql.connector
import os,json


mysql = mysql.connector.connect(user = "root",password = "",host = "localhost",database = "ayurvedik")
cur = mysql.cursor()

with open("customer.json","r") as f:
    file = f.read()
    print(file)

blueprint = Blueprint('customer',__name__)

@blueprint.route("/customer",methods = ['GET'])
def customer():
    cur.execute("select * from customer")
    data = cur.fetchall()
    cur.close()
    return str(data)

@blueprint.route("/customer_add",methods = ["POST"])
def customer_add():
    cur.execute("insert into customer(customer_id,customer_name,buy_product,quantity) values (%(customer_id)s,%(customer_name)s,%(buy_product)s,%(quantity)s)",{"customer_id":request.form["customer_id"],"customer_name":request.form["customer_name"],"buy_product":request.form["buy_product"],"quantity":request.form["quantity"]})
    mysql.commit()
    cur.close()
    return " customer id wil be added successfully"

@blueprint.route("/customer_update/<int:id>",methods = ["PUT"])
def customer_update(id):
    cur.execute('update customer set customer_name = %(customer_name)s,buy_product = %(buy_product)s,quantity = %(quantity)s where customer_id = %(customer_id)s',{"customer_id":request.form['customer_id'],"customer_name":request.form["customer_name"],"buy_product":request.form["buy_product"],"quantity":request.form["quantity"]})
    mysql.commit()
    cur.close()
    return "customer columns update success"

@blueprint.route("/customer_delete/<int:id>", methods =["DELETE"])
def customer_delete(id):
    cur.execute("delete from customer where customer_id = %(customer_id)s",{"customer_id":id})
    mysql.commit()
    cur.close()
    return "delete the id"

@blueprint.route("/soup")
def buyer():
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute("select c.customer_name,c.buy_product,c.quantity,p.product_price from customer c inner join product_man p on p.product_name= c.buy_product where c.buy_product ='soup' ")
    data = cur.fetchall()
    cur.close()
    return str(data)