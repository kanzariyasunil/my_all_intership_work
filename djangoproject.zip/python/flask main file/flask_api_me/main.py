from flask import Flask,request,make_response

app = Flask(__name__)


@app.route("/")
def index():
    return "hello world"

from blueprints.customer import blueprint as customer
from blueprints.product import blueprint as product

app.register_blueprint(customer)
app.register_blueprint(product)


if __name__ == "__main__":
    app.run(debug = True)