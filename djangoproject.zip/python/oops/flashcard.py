class flashcard:
    def __init__(self,word,meaning):
        self.word = word
        self.meaning = meaning
        
    def __str__(self):
        return self.word + '( ' + self.meaning + ')'
    
flash  =[]

print('welcome to flashcard application')


while True:
    word = input('enter the word :')
    meaning = input('enter the menaing: ')
    
    flash.append(flashcard(word,meaning))
    
    option = int(input('enter 0,if you add more option'))
    print(option)
    
    if (option):
        break

print('your flashcard is : \n')

for i in flash:
    print('>',i)

