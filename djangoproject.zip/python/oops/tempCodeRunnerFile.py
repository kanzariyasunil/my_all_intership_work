obj.display(ls[0])
# obj.display(ls[1])