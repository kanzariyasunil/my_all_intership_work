class shop:
    def __init__(self):
        pass
    
    def item(self,ingridiant,price):
        self.ingridiant = ingridiant
        self.price = price
        ls.append([self.ingridiant,self.price])
        
    def update(self,ingridiant,ch):
        for i in ls:
            if i[0] == ingridiant:
                i[1] = ch
        return 'not data match'
    def show(self):
        print(ls)

ls = []

obj = shop()
obj.item('rise',55)
obj.item('mug_dal',48)
obj.item('gol',50)
obj.item('ghee',800)
obj.show()
obj.update('rise',60)
obj.show()
