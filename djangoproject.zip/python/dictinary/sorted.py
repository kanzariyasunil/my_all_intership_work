# myDict = {'ravi': 10, 'rajnish': 9,'anuj':100,'the':120,
#         'sanjeev': 15, 'yash': 2, 'suraj': 32}

# myKeys = list(myDict.keys())
# print(myKeys)
# print(myKeys.sort())
# sorted_dict = {i: myDict[i] for i in myKeys}

# print(sorted_dict)

make_dict = dict(sorted({'anuj':34,'hub':100,'aj':200,'equal':102}.items()))
print(make_dict)

df = dict(sorted({'k':21,'j':67,'p':54,'r':21}.items()))
print(df)
d = sorted({'k':21,'j':67,'p':54,'r':21}.items())
print(dict(d))