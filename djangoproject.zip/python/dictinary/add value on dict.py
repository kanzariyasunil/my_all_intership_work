a = {'a':112,'b':23,'c':60}
a['d'] = 23
a['e'] = 20
print(a)
# other method
a.update({'r':45,'t':87})
print(a)