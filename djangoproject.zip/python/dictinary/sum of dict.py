a ={'b': 100, 'c':200, 'a':300}
b = sum(a.values())
print(b)

for i in a.values():
    i += i
print(i)
j = []
for i in a:
    j.append(a[i])
    print(j)
   # print(i)
   
