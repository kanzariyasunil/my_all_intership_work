# a = [1, 1, 1, 5, 5, 3, 1, 3, 3, 1, 4, 4, 4, 2, 2, 2, 2]
# frec = {}

# def match(my_list):
#     for i in my_list:
#         if i in frec:
#             frec[i] += 1
#         else:
#             frec[i] = 1
#     for key , values in frec.items():
#         print(key,values)
# match(a)


a = [1, 1, 1, 5, 5, 3, 1, 3, 3, 1, 4, 4, 4, 2, 2, 2, 2]
frec = {}

def catch(my_list):
    for i in my_list:
        if i in frec:
            frec[i] += 1
            print(frec[i])
        else:
            frec[i] = 1
    for key,values in frec.items():
        print(key,values)

catch(a)