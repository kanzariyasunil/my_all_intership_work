# def chr(str):
#     f = ''
#     c = 0
#     for i in range(len(str)):
#         if c == 0:
#             f += str[i].upper()
#             c = 1
#         elif str[i] == ' ':
#             f += str[i]
#             c = 0
#         else:
#             f += str[i]
#     return f
               
        

# str = 'hello world hellllllllllllo bye bye'
# print(chr(str))

def decorator(func):
    def wrapper():
        print('this is my function')
        func()
        print('ok this is now print')
    return wrapper
        
@decorator
def say_hello():
    print('dsfui')
    
say_hello()

