# test_dict = {"Gfg" : 5, "is" : 10, "Best" : 15,"for" : 4, "Geeks" : 4} 
# c = 0
# for i in test_dict.values():
#     print(i)
#     c += i
#     print('c values is ',c)
# print(f'sum of dict values is {c}  and this divide by  {len(test_dict)} and this mean is ',c/len(test_dict))

# same chareter in two string

# from collections import Counter
# def chack(ms,cs):
#     dict1 = Counter(ms)
#     dict2 = Counter(cs)
    
#     result = dict1 & dict2
    
#     return result == dict1

# str1 = 'ABHISHEKsinGH'
# str2 = 'gfhfBHkooIHnfndSHEKsiAnG'

# if (chack(str1,str2)) == True:
#     print('possible')
# else:
#     print('not possible')

# this is chack are alphabatic or not
a = 'aelpp'
def short(a):
    s = sorted(a)
    b = ''
    for i in s:
        b += i
    print(a == b)
short(a)
b = 'dhie'
short(b)