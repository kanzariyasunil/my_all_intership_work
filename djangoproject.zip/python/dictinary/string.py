# a = 'hii how  er are you'
# b = 're'
# c = ''
# for i in a:
#     for j in b:
#         if j == i :
#             c += i
            
# print(c)

# def check(string , pattern):
#     lenght = len(pattern)
#     if len(string) < lenght:
#         print('this is not print')
#     for i in range(lenght - 1):
#         x = pattern[i]
#         y = pattern[i+1]
#         last = string.rindex(x)
#         first = string.index(y)
        
#         if last == -1 or first == -1 or last > first:
#             return False
#         return True
# string = "engineers rock"
# pattern = "gsr"
# print(check(string, pattern))

def check(st,pa):
    leng = len(pa)
    if len(st) < leng:
        print('comparing string is sort')
    for i in range(leng - 1):
        x = pa[i]
        y = pa[i+1]
        
        last = st.rindex(x)
        first = st.index(y)
        
        if last == -1 or first == -1 or last > first:
            return False
        return True
s = "engineers rock"
p = "er"
print(check(s,p))
        
        
        