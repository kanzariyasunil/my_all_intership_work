# # when we write a class in side function then we write a in other side its call monkey_patch dunction

# class monkey_patch:
#     def monkey(self):
#         self.a = 23
#         self.b = 34
#         print('this is my monkeys patch',self.a+self.b)

# def patch(a,d):
#     a = 32
#     d = 389
#     print('this is patch function',a+d)
    
    
# monkey_patch.monkey = patch

# obj = monkey_patch()
# obj.monkey(400)

# Python program to illustrate
# *kwargs for variable number of keyword arguments


def myFun(**kwargs):
    for key, value in kwargs.items():
        print(f"{key} == {value}")


# Driver code
myFun(first='Geeks', mid='for', last='Geeks')
