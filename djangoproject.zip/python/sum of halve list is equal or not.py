a = [1,26,3,4,5,5,4,3,26,1]
d = len(a) //2
for i in a:
    if (len(a) // 2 == 1):
        print('list are not divide to even numbers')
b = sum(a[:d])
c= sum(a[-d:])
if b == c:
    print('both are same ')
else :
    print('both are not same')
