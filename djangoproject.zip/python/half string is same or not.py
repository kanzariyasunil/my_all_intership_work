a = 'abcdcdba'
b = len(a) //2
add= 0
for idx ,j in enumerate(a):
    if idx >= b:
        
        a[idx] += 1
print(a)
