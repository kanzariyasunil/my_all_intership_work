# find the differnece in to string
a = 'bcsas'
b = 'nandb'
k = [i for i in a if i not in b] + [i for i in b if i not in a]
print('the differnce of two string',k)