from typing import List
def singleNumber( nums: List[int]) -> int:
        l = 0
        r = len(nums) - 1
        while l<r:
            if nums[l] == nums[r]:
                print(nums[l],nums[r])
                l += 1
                r = len(nums) - 1
            else:
                r -= 1    
    
nums = [2,2,1]
print(singleNumber(nums))