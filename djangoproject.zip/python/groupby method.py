a = [1,2,2,3,4,5,3,1,2]
import itertools
for (key,group) in itertools.groupby(a):
    print(key,list(group))
    
s = ['dhssdds',3,4,5,3,22,22,22,3,4,'dhfuudddsj']
for (key,group) in itertools.groupby(s):
    print(key,list(group))