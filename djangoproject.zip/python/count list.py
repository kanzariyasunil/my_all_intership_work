l = [[1,2,3,4,2,5,2,26,7],[34,56,23,12,45,68,67,3]]
print(len(l[1]))
for idx ,j in enumerate(l):
    print(idx,j)
    print('4 has bin appear',l[idx].count(4))
