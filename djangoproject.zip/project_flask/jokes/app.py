from flask import Flask ,render_template,request
import pyjokes 

app=Flask(__name__) 



@app.route("/") 
def index():
    jokes = pyjokes.get_jokes()
    page = request.args.get('page', 1, type=int)
    per_page = 10
    start = (page - 1) * per_page
    ends = start + per_page
    total_page = (len(jokes) + per_page - 1) // per_page
    item_on_page = jokes[start:ends]
    return render_template('index.html',jokes=jokes,page = page,per_page = per_page,item_on_page=item_on_page,total_page=total_page)

@app.route("/MultipleJokes") 
def jokes(): 
	jokes=pyjokes.get_jokes() #Here, we get a list of jokes. 
	return f'<h2>{jokes}</h2>'

if __name__ == "__main__": 
	app.run(debug=True)
