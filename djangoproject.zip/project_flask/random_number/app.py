from flask import Flask,render_template,request,redirect,url_for,flash
import random as rn

app = Flask(__name__)

random  = rn.randint(0,10)


@app.route('/index',methods = ["GET",'POST'])
def home():
    c = 0
    while True:
        if random == int(request.form['random']):
            message = 'succes guess the number'
            return render_template('index.html',message = message)
        elif random > int(request.form['random']):
            message = 'random number is greater'
            return render_template('base.html',message = message)
        elif random < int(request.form['random']):
            message = 'random number is smaller'
            return render_template('base.html',message = message)
    
@app.route('/',methods = ["GET",'POST'])
def index():
    message = 'try your best'
    return render_template('index.html',message = message)

if __name__ == '__main__':
    app.run(debug=True,port = 5000)