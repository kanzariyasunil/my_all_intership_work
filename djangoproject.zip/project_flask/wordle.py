guess_word = [['']*5, ['']*5, ['']*5, ['']*5, ['']*5]
wordle = [['a','c','o','r','n'], ['b','r','i','g','h'], ['c','a','n','d','l'], ['d','e','s','i','g'], ['f','u','t','u','r']]
count = 0


for i in range(0,5):
    for j in range(0,5):
        if count == 5:
            print('enough try')
            c = 0
        word = input('Enter a 5 letter word: ')
        guess_word[i][j] = word
        print(guess_word)
        if wordle[i][j] == guess_word[i][j]:
            print('green')
        elif guess_word[i][j] in wordle[i]:
            print('yellow')
        else:
            print('red')
        count += 1
        