from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# List of possible words for the game
WORD_LIST = ["apple", "brave", "crane", "drape", "eagle"]  # Add more words as needed
SECRET_WORD = random.choice(WORD_LIST)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/guess', methods=['POST'])
def guess():
    user_guess = request.form.get('guess').lower()
    if len(user_guess) != 5 or user_guess not in WORD_LIST:
        return jsonify({"error": "Invalid word"}), 400

    result = get_wordle_feedback(user_guess)
    return jsonify({"result": result})

def get_wordle_feedback(guess):
    feedback = []
    for i, char in enumerate(guess):
        if char == SECRET_WORD[i]:
            feedback.append('G')  # Green for correct letter in correct place
        elif char in SECRET_WORD:
            feedback.append('Y')  # Yellow for correct letter in wrong place
        else:
            feedback.append('B')  # Black for incorrect letter
    return ''.join(feedback)

if __name__ == '__main__':
    app.run(debug=True)
