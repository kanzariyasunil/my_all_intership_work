from flask import Flask, render_template, request, redirect, url_for
from flask_mail import Mail, Message
from dotenv import load_dotenv
load_dotenv()
import os

app = Flask(__name__)

# Configure the Flask app
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = os.getenv('MAIL')
app.config['MAIL_PASSWORD'] = os.getenv('PASSWORD')
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

mail = Mail(app)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/sendemail/", methods=['POST'])
def sendemail():
    if request.method == "POST":
        name = request.form['name']
        subject = request.form['Subject']
        email = request.form['_replyto']
        message = request.form['message']

        yourEmail = os.getenv('YOUR_EMAIL')

        try:
            msg = Message(subject=subject,
                          sender=email,
                          recipients=[yourEmail],
                          body=f"First Name: {name}\nEmail: {email}\nSubject: {subject}\nMessage: {message}")
            mail.send(msg)
            print("Email sent successfully.")
        except Exception as e:
            print(f"Failed to send email. Error: {e}")

    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)
