from flask import Flask,render_template,request,jsonify
import random

app  = Flask(__name__)

list = ['apple','brave','linos','fight']
key = random.choice(list)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/guess',methods = ['POST'])
def guess():
    user_guess = request.form.get('guess').lower()
    if len(user_guess) != 5 and user_guess not in list:
        return jsonify({'message':'wrong lenght or all characters guess wrong'}),400
    
    result = guess_word(user_guess)
    return jsonify({'result':result})

def guess_word(guess):
    add  = []
    for i,char in enumerate(guess):
        if char == key[i]:
            add.append('g')
        elif char in key:
            add.append('y')
        else:
            add.append('b')
    return ''.join(add)

if __name__ == "__main__":
    app.run(debug=True)
