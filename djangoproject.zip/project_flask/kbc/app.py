from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a secure key

# Sample questions
questions = [
    {"question": "What is the capital of France?", "options": ["Berlin", "Madrid", "Paris", "Rome"], "answer": "Paris"},
    {"question": "What is 2 + 2?", "options": ["3", "4", "5", "6"], "answer": "4"},
    {"question": "What is the largest ocean?", "options": ["Atlantic", "Indian", "Arctic", "Pacific"], "answer": "Pacific"}
]

@app.route('/')
def index():
    session['question_index'] = 0
    return redirect(url_for('question'))

@app.route('/question', methods=['GET', 'POST'])
def question():
    index = session.get('question_index', 0)
    if index >= len(questions):
        return render_template('end.html')

    question = questions[index]
    if request.method == 'POST':
        selected_option = request.form.get('option')
        if selected_option == question['answer']:
            session['question_index'] = index + 1
            return redirect(url_for('question'))
        else:
            return render_template('incorrect.html')

    return render_template('question.html', question=question)

@app.route('/end')
def end():
    return render_template('end.html')

if __name__ == '__main__':
    app.run(debug=True)
