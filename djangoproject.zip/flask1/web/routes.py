import os
import secrets
from flask import render_template,flash,redirect,url_for,request
from web import app,db,bcrypt
from web.form import RegisterForm,LoginForm,UpdateAccountForm,PostForm
from web.models import User,Post
from flask_login import login_user,current_user,logout_user,login_required
posts = [
    
{
    'author':'corey',
    'title':'blog',
    'content':'first blog',
    'date':'10-3-2020'
},
{
    'author':'aroy',
    'title':'blog 2',
    'content':'third blog',
    'date':'10-3-2022'
},
{
    'author':'abhay',
    'title':'page',
    'content':'make blog',
    'date':'10-3-2023'
}
]










        