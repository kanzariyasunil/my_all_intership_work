from web import app
from web import db
from web.models import User
if __name__ == '__main__':
    app.run(debug = True)
