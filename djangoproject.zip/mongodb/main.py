from flask import Flask, request
from flask_pymongo import PyMongo
import json

app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb://localhost:27017/myDatabase"
mongo = PyMongo(app).db

@app.route('/')
def hello():
    return 'add'

@app.route('/add', methods=['POST'])
def add():
    mongo.inventory.insert_one({'name': request.form['name'], 'sername': request.form['sername']})
    return 'done'

@app.route('/see', methods=['GET'])
def see():
    data = mongo.inventory.find()
    data_list = list(data)
    print(data_list)
    return json.dumps(data_list, default=str)  

if __name__ == "__main__":
    app.run(debug=True)
