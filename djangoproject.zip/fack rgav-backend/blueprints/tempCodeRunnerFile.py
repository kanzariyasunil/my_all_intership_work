print(json.dumps(data))

# payment_url = data["data"]["instrumentResponse"]["redirectInfo"]["url"]
# transaction_id = data["data"]["merchantTransactionId"]
# print("transaction_id - ", transaction_id)
# print("pay