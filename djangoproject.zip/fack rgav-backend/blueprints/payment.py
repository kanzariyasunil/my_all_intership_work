import hashlib
import requests
import json
import uuid

def create_sha256_string(input_string):
    sha256_hash = hashlib.sha256(input_string.encode())
    encoded_string = sha256_hash.hexdigest()
    return encoded_string

def phonepe_payment_url(amount):
    # Generate unique IDs
    order_id = "pp-" + str(uuid.uuid4())
    user_id = "user-" + str(uuid.uuid4())
    merchant_transaction_id = "MT" + str(uuid.uuid4())
    mobile_number = "9999999998"  # test mobile number
    email = "test@example.com"

    payload = {
        "amount": amount * 100,
        "merchantId": "YOUR_PHONEPE_MERCHANT_ID",
        "merchantTransactionId": merchant_transaction_id,
        "merchantUserId": user_id,
        "redirectUrl": "YOUR_CALLBACK_URL",
        "redirectMode": "POST",
        "callbackUrl": "YOUR_CALLBACK_URL",
        "merchantOrderId": order_id,
        "mobileNumber": mobile_number,
        "email": email,
        "message": "Payment for " + order_id,
        "paymentInstrument": {"type": "PAY_PAGE"}
    }

    json_data = json.dumps(payload)
    base64_request = json_data.encode("utf-8").decode("ascii")

    # X-VERIFY header
    final_x_header = create_sha256_string(base64_request + "/pg/v1/pay" + "YOUR_SALT_KEY") + "###YOUR_SALT_INDEX"

    req = {"request": base64_request}

    final_header = {"Content-Type": "application/json", "X-VERIFY": final_x_header}

    response = requests.post("https://api.phonepe.com/pg/v1/pay", headers=final_header, json=req)

    if response.status_code == 200:
        return response.json()
    else:
        return "Something went wrong - " + response.text

res = phonepe_payment_url(100)
print(res)



# /data = json.loads(res)
# print(json.dumps(data))

# payment_url = data["data"]["instrumentResponse"]["redirectInfo"]["url"]
# transaction_id = data["data"]["merchantTransactionId"]
# print("transaction_id - ", transaction_id)
# print("payment_url - ", payment_url)