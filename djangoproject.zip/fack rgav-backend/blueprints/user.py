from flask import request, jsonify, Blueprint
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, set_access_cookies, set_refresh_cookies, get_jwt_identity
from database import make_db_call
from dotenv import load_dotenv
import os, json

load_dotenv()

blueprint = Blueprint('user', __name__)

file_name = os.environ.get('QUERY_PATH') + 'user.json'

try:
    if os.path.exists(file_name):
        with open(file_name, 'r') as file:
            queries = json.load(file)
    else:
        print('file does not exist')
except Exception as e:
    print(e)

@blueprint.route('/register', methods=['POST'])
def register():
    user_email = request.form['user_email']
    if make_db_call(query=queries['get_user_count'], type='returns', parameter={'user_email': user_email})[0][0] == 1:
        return "This email already exists. Please login", 400
    
    make_db_call(query=queries['register'], type='', parameter={
        'username': request.form['username'],
        'user_email': user_email,
        'password': request.form['password'],
        'phone': request.form['phone']
    })
    
    return jsonify({'message': 'Registered successfully'}), 201

@blueprint.route('/login', methods=['POST'])
def login():
    email = request.form['user_email']
    password = request.form['password']
    
    if make_db_call(query=queries['get_user_count'], type='returns', parameter={"user_email": email})[0][0] == 0:
        return 'This user is not registered. Please register first', 404
    
    user_data = make_db_call(query=queries['login'], type='returns', parameter={"user_email": email, "password": password})
    
    if not user_data:
        return 'Invalid credentials', 401
    
    access_token = create_access_token(identity=email, fresh=True)
    refresh_token = create_refresh_token(identity=email)
    
    response = jsonify({
        'message': refresh_token
    })
    
    set_access_cookies(response, access_token)
    set_refresh_cookies(response, refresh_token)
    
    return response

@blueprint.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify(logged_in_as=current_user), 200

@blueprint.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    current_user = get_jwt_identity()
    access_token = create_access_token(identity=current_user, fresh=False)
    return jsonify(access_token=access_token)