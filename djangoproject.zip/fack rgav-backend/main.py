from flask import Flask
from datetime import timedelta
from flask_jwt_extended import JWTManager
from blueprints.user import blueprint as user
from blueprints.product import blueprint as product

app = Flask(__name__)

# Set up JWT configuration
app.config["JWT_SECRET_KEY"] = "nowyouknowsreacetkey"  # Change this to a secret key of your choice
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(seconds=15)  # Adjust token expiration time as needed
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(minutes=1)  # Adjust token expiration time as needed

jwt = JWTManager(app)

app.register_blueprint(user)
app.register_blueprint(product)

@app.route('/')
def hello_world():
    return 'Hello, World!'

if __name__ == "__main__":
    app.run(debug=True, port=5001)
