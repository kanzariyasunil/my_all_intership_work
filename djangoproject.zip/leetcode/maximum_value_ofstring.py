def string(num):
    s = 0
    k = 0
    for i in range(len(num)):
        if num[i].isdigit():
            print(int(num[i]))
            s = max(s, int(num[i]))
        s = max(s, len(num[i]))
    return s
print(string(['1','01','001']))


