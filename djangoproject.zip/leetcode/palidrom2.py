def palindromme(string):
    l,r = 0, len(string) - 1
    while l<r:
        if string[l] != string[r]:
            return False
        first = seconde = True
        l2,r2,l3,r3 = l+1,r,l,r-1
        while l2>r2:
            if string[l2] != string[r2]:
                break
            l2+=1
            r2-=1
            
        while l3<r3:
            if string[l3] != string[r3]:
                break
            l3+=1
            r3-=1
                
        if first or seconde:
            return True
        else:
            first = seconde = True
            l2,r2,l3,r3 = l+1,r-1,l,r-2
            while l2<r2:
                if string[l2] != string[r2]:
                    first = False
                    break
                l2+=1
                r2-=1
            while l3<r3:
                if string[l3] != string[r3]:
                    seconde = False
                l3+=1
                r3-=1
            if first or seconde:
                return True
            else:
                return False 


print(palindromme("abba"))