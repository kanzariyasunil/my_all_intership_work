def largets_odd_num(str):
    h = len(str) - 1
    for i in range(len(str)-1):
        if str[h] == "0":
            h -= 1
    str = str[:h+1]
    
    if int(str[-1]) % 2 == 1:
        return str
    large = "0"
    for i in range(len(str)):
        if int(str[i]) % 2 == 1:
            if int(large) < int(str[i]):
                large = str[i]
    if int(large) > 0:
        return large
    else:
        return ""

print(largets_odd_num("2226666888"))