# def single_number(nums):
#     d = {}
    
#     for i in nums:
#         if i not in d:
#             d[i] = 1
#         else:
#             d[i] += 1
#     for i in d:
#         if d[i] == 1:
#             return i

def singleNumber(nums):
        result = 0
        for number in nums:
            result ^= number
            print(result)
        return result

print(singleNumber([1,2,1,3,2,5]))