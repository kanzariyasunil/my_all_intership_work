a =  lambda x ,y,z: (x+y) * z
b = lambda x,y:x*y 
print([b(5,4) for i in range(5) if i%2 == 0 ] )
