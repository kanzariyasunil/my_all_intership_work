def number_bit(num):
    num = bin(num)
    c = 0
    for i in num:
        if i == '1':
            c += 1
    return c
    
print(number_bit(2147483645))