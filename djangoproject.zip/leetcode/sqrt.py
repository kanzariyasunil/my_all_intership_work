def sqrt(num):
    if num == 0 or num == 1:
        return num
    start = 1
    end = num
    while start <= end:
        mid = (start + end) //2
        if mid * mid == num:
            return mid
        elif mid*mid < num:
            start = mid + 1
        else:
            end = mid - 1
    return end


print(sqrt())