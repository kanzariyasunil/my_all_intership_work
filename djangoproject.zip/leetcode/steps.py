def count(lst):
    min_length = len(lst[0])
    for i in range(len(lst)):
        min_length = min(min_length,len(lst[i]))
    lcp = ''
    
    print('sdafhi')
    for i in range(min_length):
        j = 0
        ch = lst[0][i]
        while j < len(lst):
            if ch != lst[j][i]:
                return lcp
            j += 1
        lcp += ch 
    return lcp
    
print(count(['flower','flow','flex']))