class bird:
    def intro(self):
        print('this is intro part')
        
    def flying(self):
        print('this is bird part of flting')
    
    
class bird1(bird):
    def flying(self):
        print('ird1 bird enter')

class bird2(bird):
    def flying(self):
        print('ird2 bird enter')
    
obj = bird1()
obj.flying()
obj.intro()
