def Number(string):
    s = 0
    for i in range(len(string)):
        if int(string[i]) > 0:
            k = len(string) - i
            print(k)
            break



k = "00010000"
Number(k)