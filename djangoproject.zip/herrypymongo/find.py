import pymongo

if __name__ == "__main__":
    print('welcome to mongodb')
    client = pymongo.MongoClient("mongodb://localhost:27017")
    db = client['one']
    collation = db['anycollation']
    # you can find one data 
    # data = collation.find_one({'name':'othe'})
    
    
    # more data load use find word
    
    # data = collation.find({'name':'or jinedo'} , {'name':1,'_id':0})
    # for name in data:
    #     print(name)
    
    
    # with given percticular column print that give 1 and column not neccary is give 0
    # data = collation.find({'name':'or jinedo'} , {'name':1,'_id':0})
    
    #you can use this is make set  limit
    data = collation.find({'name':'or ',"add":"jo"} , {"_id":0}).limit(4)
    
    for name in data:
        print(name)