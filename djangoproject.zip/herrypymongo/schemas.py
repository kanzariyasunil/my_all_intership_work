from pymongo import MongoClient
from datetime import datetime as dt
import json


client = MongoClient('mongodb://localhost:27017/')
db = client.bhima
# collation = db['obj']
def create_auther():
    result = db.create_collection('author', validator={
            '$jsonSchema': {
                'bsonType': 'object',
                'additionalProperties': True,
                'required': ['name', 'lastname','age','birth'],
                'properties': {
                    'name': {
                        'bsonType': 'string'
                    },
                    'lastname': {
                        'bsonType': 'string',
                        'description': 'Set to default value'
                    },
                    'age':{
                        'bsonType': 'int',
                    },
                    'birth':{
                        'bsonType': 'date',
                    }
            }
        }}) 
                                

def create_book():
    db.create_collection('book',validator={
        '$jsonSchema': {
                'bsonType': 'object',
                'additionalProperties': True,
                'required': ['book', 'author','date','copy'],
                'properties': {
                    'book': {
                        'bsonType': 'string'
                    },
                    'author': {
                        'bsonType': 'string',
                        'description': 'Set to default value'
                    },
                    'copy':{
                        'bsonType': 'int',
                    },
                    'date':{
                        'bsonType': 'date',
                    }
            }
        }}) 

def addit_authorname_bookname():
    author_name = [
    {
        "name": "Alice",
        "lastname": "Johnson",
        "age": 28,
        "birth": dt(1996, 5, 15)
    },
    {
        "name": "Bob",
        "lastname": "Smith",
        "age": 34,
        "birth": dt(1989, 9, 22)
    },
    {
        "name": "Charlie",
        "lastname": "Brown",
        "age": 22,
        "birth": dt(2002, 1, 10)
    },
    {
        "name": "Diana",
        "lastname": "White",
        "age": 45,
        "birth": dt(1979, 11, 3)
    },
    {
        "name": "Ethan",
        "lastname": "Williams",
        "age": 30,
        "birth": dt(1993, 3, 14)
    },
    {
        "name": "Fiona",
        "lastname": "Taylor",
        "age": 26,
        "birth": dt(1997, 7, 20)
    },
    {
        "name": "George",
        "lastname": "Martin",
        "age": 40,
        "birth": dt(1983, 12, 1)
    },
    {
        "name": "Hannah",
        "lastname": "Clark",
        "age": 19,
        "birth": dt(2005, 2, 28)
    },
    {
        "name": "Ian",
        "lastname": "Garcia",
        "age": 50,
        "birth": dt(1973, 4, 5)
    },
    {
        "name": "Julia",
        "lastname": "Martinez",
        "age": 36,
        "birth": dt(1988, 8, 12)
    }
]

    author_add = db.author
    author_add.insert_many(author_name)
    
    
def book_add():
    data = db.author
    store = []
    for i in data.find({},{"name":1,"_id":0}):
        store.append(i['name'])
    book_add = db.book
    book_name = [
    {
        "book": "The Great Gatsby",
        "author": store[5],
        "date": dt.today(),
        "copy": 5
    },
    {
        "book": "To Kill a Mockingbird",
        "author": store[7],
        "date": dt.today(),
        "copy": 3
    },
    {
        "book": "1984",
        "author": store[2],
        "date": dt.today(),
        "copy": 4
    },
    {
        "book": "Pride and Prejudice",
        "author": store[3],
        "date": dt.today(),
        "copy": 6
    },
    {
        "book": "The Catcher in the Rye",
        "author": store[4],
        "date": dt.today(),
        "copy": 2
    },
    {
        "book": "The Hobbit",
        "author": store[5],
        "date": dt.today(),
        "copy": 7
    },
    {
        "book": "Fahrenheit 451",
        "author": store[6],
        "date": dt.today(),
        "copy": 5
    },
    {
        "book": "Brave New World",
        "author": store[7],
        "date": dt.today(),
        "copy": 3
    },
    {
        "book": "Moby Dick",
        "author": store[0],
        "date": dt.today(),
        "copy": 4
    },
    {
        "book": "War and Peace",
        "author": store[1],
        "date": dt.today(),
        "copy": 1
    }
]
 

    book_add.insert_many(book_name)
