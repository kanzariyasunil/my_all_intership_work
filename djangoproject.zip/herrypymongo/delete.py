import pymongo

if __name__ == "__main__":
    client = pymongo.MongoClient("mongodb://localhost:27017")
    db = client['one']
    collaction = db['anycollation']
    
    # this is can be delete only one row match pair
    # collaction.delete_one({"name":"or jinedo"})
    
    #this is can be delete all row match pair
    collaction.delete_many({"name":"or jinedo"})
    
    
    
    