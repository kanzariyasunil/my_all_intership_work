import pymongo,json

if __name__ == "__main__":
    print('welcome')
    client = pymongo.MongoClient("mongodb://localhost:27017")
    db = client['one']
    collation = db['anycollation']
    # add only one item
    # collation.insert_one({'name':'or jinedo','add':'jio'})
    
    
    # add multiple item using insert_many
    insert_many = [
        {'name':'or ','add':'jio'},
        {'name':'or ','add':'io'},
        {'name':'or ','add':'jo'},
        {'name':'or ','add':'ji'},
        {'name':'or ','add':'o'},
        {'name':'or ','add':'jo'},
        {'name':'or ','add':'jiot'},
        {'name':'or ','add':'jios'},
        {'name':'or ','add':'jiosd'},
    ]
    collation.insert_many(insert_many)
    # print the all data
    # print(json.dumps(list(collation.find()),default=str))