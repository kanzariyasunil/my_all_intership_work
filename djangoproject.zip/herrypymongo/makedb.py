import pymongo,json

if __name__ == "__main__":
    print('welcome')
    client = pymongo.MongoClient("mongodb://localhost:27017") 
    db = client['one'] # make makebase
    collation = db['anycollation']
    
    # show all database 
    print(client.list_database_names())