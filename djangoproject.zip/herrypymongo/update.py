import pymongo

if __name__ == "__main__":
    client = pymongo.MongoClient("mongodb://localhost:27017")
    db = client['one']
    collation  = db['anycollation']
    
    prev = {"name":"or jinedo"}
    nextt = {"$set":{"add":"campus"}}
    
    # this is update only one data
    # collation.update_one(prev,nextt)
    
    # this is updte all data when name id or jinedo
    collation.update_many(prev,nextt)
    