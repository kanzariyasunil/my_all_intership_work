def chack(string,no):
    new_string = string[:no] + string[no+1:]
    return new_string

s = 'GeekForGeeks'
no = 5
print(chack(s,no))
s = 'this is no can remove'
no = 10
print(chack(s,no))
s = 't'
no = 1
print(chack(s,no))
#string = 'this is a string program'
        

