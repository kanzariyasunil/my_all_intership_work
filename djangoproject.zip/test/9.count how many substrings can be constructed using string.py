def chack(string,cs):
    f = [ch for ch in string if ch in cs]
    print(f)
    print(f'{cs} is count times:',int(len(f)/len(cs)))
test_str = 'geksefokesgergeeks'
arg_str = 'geek'
chack(test_str,arg_str)
time ='timestoneisgivetime'
t ='time'
chack(time,t)

# this is not complete