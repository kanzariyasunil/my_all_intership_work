def chack(string):
    c = 1
    new_string = ''
    for i in string:
        if i not in string[c:]:
            new_string += i
        c += 1
    return new_string
st = 'geeksforgeeks'
print(chack(st))
st = 'this is a similar type of words is this '
print(len(chack(st)))
st = 'i'
print(chack(st))
