# s = "A man, a? plan, a canal: Panama"
# def chack(string):
#     a = ',.;: '
#     for i in a:
#         if i in string:
#             string = string.replace(i,'')
#     print(string[::-1].lower() == string.lower())

# chack(s)
# d = ' '
# chack(d)
# s = "race a car"
# chack(s)

# 65-90
# 97-122

def pali(s):
    l = 0
    r = len(s)-1
    while r>l:
        if ord(s[r].lower()) < 97 or ord(s[r].lower()) > 122:
            r -= 1
            continue
        if ord(s[l].lower()) < 97 or ord(s[l].lower()) > 122:
            l += 1
            continue
        if s[l].lower() != s[r].lower():
            return False
        l += 1
        r -= 1
    return True

print(pali("A man, a? plan, a canal: Panama"))
print(pali("race a car"))