no = 14, 625, 498.002

def chack(string):
    string = str(no)
    st1 = string.replace(',','no')
    st2 = st1.replace('.',',')
    st3 = st2.replace('no','.')
    print(st3)
chack(no)
no = "23,45,566.334,56no"
chack(no)
