s = 'zero four zero one'
def chack(string):
    s= string.split()
    a = ''
    for i in s:
        if i == 'zero':
            a += '0'
        elif i == 'one':
            a += '1'
        elif i == 'two':
            a += '2'
        elif i == 'three':
            a += '3'
        elif i == 'four':
            a += '4'
        elif i == 'five':
            a += '5'
        elif i == 'six':
            a += '6'
        elif i == 'seven':
            a += '7'
        elif i == 'eight':
            a += '8'
        elif i == 'nine':
            a += '9'
        else:
            print('you have not input valid number')
    print(a)
chack(s)
s = 'zero four zero one nine seven eight two'
chack(s)
s = 'zero seven sdf'
chack(s)