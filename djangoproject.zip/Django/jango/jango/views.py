from django.http import HttpResponse
from django.shortcuts import render
def home(request):
    #return HttpResponse("Hello, world. You're at the jango home.")
    return render(request, 'index.html')

def about(request):
    return HttpResponse("Hello, world. You're at the jango about.")

def index(request):
    return HttpResponse("Hello, world. You're at the jango index.")

def hole(request):
    return HttpResponse("Hello, world. You're at the jango hole.")