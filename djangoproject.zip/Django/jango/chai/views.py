from django.shortcuts import render
from .models import ChaiVarity,ChaiReview,Store
from django.shortcuts import get_object_or_404
from .form import ChaiVarityForm

def chai_all(request): # this function give in ursl.py
    chais = ChaiVarity.objects.all()
    return render(request,'chai/index.html',{"chais":chais})


def chai_detials(request,chai_id):
    chai = get_object_or_404(ChaiVarity,pk=chai_id)
    return render(request,'chai/chai_details.html',{'chai':chai})

def chai_store_view(request):
    stores = None
    if request.method == 'POST':
        form = ChaiVarityForm(request.POST)
        if form.is_valid():
            chai_verity = form.cleaned_data['chai_varity']
            stores = Store.objects.filter(chai_varities = chai_verity)
    else:
        form = ChaiVarityForm()
    return render(request,'chai/chai_store.html',{'stores':stores,'form':form})