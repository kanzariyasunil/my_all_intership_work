from django.urls import path
from . import views
urlpatterns = [
    path('',views.chai_all,name = 'all_chai'),
    path('<int:chai_id>/',views.chai_detials,name = 'chai_details'),
    path('chai_store/',views.chai_store_view,name = 'chai_store'),
]
