from flask import Flask,render_template,redirect,url_for,session,flash,request
from flask_wtf import FlaskForm
from wtforms import StringField,validators,PasswordField,SubmitField
from wtforms.validators import DataRequired,Email,ValidationError
from flask_mysqldb import MySQL


app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'mysqldatabase'


app.secret_key = 'scerete_key'

mysql = MySQL(app)

class RegisterForm(FlaskForm):
    name = StringField("name",validators=[DataRequired()])
    email = StringField("email",validators=[DataRequired(),Email()])
    password = PasswordField("password",validators=[DataRequired()])
    submit = SubmitField("Register")
    
    def validate_email(self,field):
        cursor = mysql.connection.cursor()
        cursor.execute("select * from users where email = %s",(field.data,))
        user = cursor.fetchone()
        cursor.close()
        if user:
            raise ValidationError("email already exists")

class LoginForm(FlaskForm):
    email = StringField("email",validators=[DataRequired(),Email()])
    password = PasswordField("password",validators=[DataRequired()])
    submit = SubmitField("login")
    
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        name = form.name.data
        email = form.email.data
        password = form.password.data
        cursor = mysql.connection.cursor()
        cursor.execute('INSERT INTO users (name, email, password) VALUES (%s, %s, %s)', (name, email, password))
        mysql.connection.commit()  # Make sure to call commit on the connection
        cursor.close()
            
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route('/login',methods = ['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        
        cursor = mysql.connection.cursor()
        cursor.execute('select * from users where email = %s', (email,))
        user = cursor.fetchone()
        
        mysql.connection.commit()  # Make sure to call commit on the connection
        cursor.close()
        print(request.form['password'])
        if user and password == user[3]:
            session['user_id'] = user[0]
            return redirect(url_for('dashboard'))
        else:
            flash('login failed please check your email and password')
            return redirect(url_for('login'))
            
    return render_template('login.html', form=form)
@app.route('/dashboard',methods = ['GET','POST'])
def dashboard():
    if 'user_id' in session:
        user_id = session['user_id']
        cursor = mysql.connection.cursor()
        cursor.execute('select * from users where id = %s',(user_id,))
        user = cursor.fetchone()
        cursor.close()
        return render_template('dashboard.html',user= user)
    return redirect(url_for('login'))
@app.route('/logout')
def logout():
    session.pop('user_id',None)
    flash ('you have logout ')
    return redirect(url_for('login'))
if __name__ == "__main__":
    app.run(debug = True)