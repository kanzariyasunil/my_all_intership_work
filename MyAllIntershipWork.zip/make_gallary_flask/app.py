from flask import Flask,render_template,request,redirect,send_from_directory
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'

db = SQLAlchemy(app)

class File(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    filename = db.Column(db.String(200),nullable = False)
    
with app.app_context():
    db.create_all() 
@app.route('/')
def index():
    files = File.query.all()
    return render_template('index.html',files = files)

@app.route('/upload', methods=['POST'])
def uploads():
    if request.method == 'POST':
        if 'file' in request.files:
            file = request.files['file']
            if file:
                filename = file.filename
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                new_file = File(filename=filename)
                db.session.add(new_file)
                db.session.commit()
                return redirect('/')
        return "No file was provided"
    return "something went wrong"

@app.route('/upload_file/<filename>')
def upload_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'],filename)

if __name__ == "__main__":
    app.run(debug = True)