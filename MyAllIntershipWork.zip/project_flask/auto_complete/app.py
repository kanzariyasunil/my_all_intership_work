from flask import Flask, request, render_template 


app = Flask(__name__) 


@app.route("/", methods=["POST", "GET"]) 
def home(): 
	if request.method == "GET": 
		languages = ["Python","JavaScript","Java","C++","C#","Ruby","Swift","Go","Kotlin","PHP","TypeScript","R","SQL","MATLAB","Perl","Rust","Scala","Haskell","Lua","Objective-C","Dart",
                   
    "NumPy",       
    "Pandas",      
    "Matplotlib",  
    "SciPy",       
    "TensorFlow",  
    "Keras",       
    "Flask",       
    "Django",      
    "Requests",    
    "BeautifulSoup"
    "PyTorch",     
    "SQLAlchemy",  
    "OpenCV"       
    "libc",        
    "GLFW",        
    "SDL",         
    "OpenGL",      
    "Boost",       
    "Curl",        
    "GMP",         
    "LibXML2",     
    "PCRE",        
    "SQLite"       
    "React",       
    "Vue",         
    "Angular",     
    "jQuery",      
    "Lodash",      
    "D3",          
    "Moment.js",   
    "Axios",       
    "Three.js",     
    "Express.js"    
]
		
		return render_template("index.html", languages=languages) 


if __name__ == '__main__': 
	app.run(debug=True) 
