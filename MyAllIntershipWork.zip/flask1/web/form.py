from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,SubmitField,TextAreaField
from wtforms.validators import Email,DataRequired,Length,EqualTo,ValidationError
from web.models import User
from flask_login import current_user
from flask_wtf.file import FileAllowed,FileField

            
