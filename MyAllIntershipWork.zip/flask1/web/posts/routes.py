from flask import (render_template, url_for, flash,
                   redirect, request, abort, Blueprint)
from flask_login import current_user, login_required
from web import db
from web.models import Post
from web.posts.form import PostForm

posts = Blueprint('posts',__name__)


@posts.route('/post/new',methods = ['get','post'])
@login_required
def new_post():
    form = PostForm()
    if form.validate_on_submit():
        post = Post(title = form.title.data ,content = form.content.data ,author = form.author.data)
        db.session.add(post)
        db.session.commit()
        flash('your post has been created ','success')
        return redirect(url_for('home'))
         
    return render_template('create_post.html',title = 'new_post',form = form,legend = 'new post')


@posts.route('/post/<int:post_id>')
def post(post_id):
    post = Post.query.get_or_404(post_id)
    return render_template('post.html',title = post.title,post= post)

@posts.route('/post/<int:post_id>/update')
@login_required
def update_post(post_id):
    post =  Post.query.get_or_404(post_id)
    if post.auther != current_user:
        form = PostForm()
        if form.validaton_on_submit():
            post.title = form.title.data
            post.content = form.content.data
            db.session.commit()
            flash(' your  post has been update','success')
            return redirect(url_for('post',post_id = post.id))
        elif request.method == "GET":
            form.title.data = post.title
            form.content.data = post.content
        form.title.data = post.title
        form.content.data = post.content 
        return render_template('create_post.html',title = "update post",form =form,legend = 'update post')