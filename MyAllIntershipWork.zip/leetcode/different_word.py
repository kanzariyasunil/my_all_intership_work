def subsquantant(s1,s2):
    s1 = s1.split()
    s2 = s2.split()
    d = {}
    
    for i in s1:
        if i not in d:
            d[i] = 1
        else:
            d[i] += 1
    for i in s2:
        if i not in d:
            d[i] = 1
        else:
            d[i] += 1
    add = []
    for i in d:
        if d[i] == 1:
            add.append(i)
    return add

print(subsquantant('hello world this is beautiful world','hello world'))
    
    
    
    
    
    