dict = {
    1:20,
    2:30,
    1:30,
    "this":"that",
    "ok":"not ok",
    "offer":{"a":1,"b":2}
}
for i in dict['offer']:
    print(i,dict['offer'][i])

Dict = {}
print("Empty Dictionary: ")
print(Dict)
Dict[0] = 'Geeks'
Dict[2] = 'For'
Dict[3] = 1
print("\nDictionary after adding 3 elements: ")
print(Dict)

Dict['Value_set'] = 2, 3, 4
print("\nDictionary after adding 3 elements: ")
print(Dict)

Dict[2] = 'Welcome'
print("\nUpdated key value: ")
print(Dict)
Dict[5] = {'Nested': {'1': 'Life', '2': 'Geeks'}}
print("\nAdding a Nested Key: ")
print(Dict)

# assecing multiple elements
for i in Dict[5]:
    print(i,Dict[5]['Nested']['1'])



# function 

def short(text):
    return text

def lower(text):
    return text.lower()

def swith(func):
    print(func(5*9))
swith(short)