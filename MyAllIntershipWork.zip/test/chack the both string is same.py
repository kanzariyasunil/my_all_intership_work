test_str1 = 'eeksg'
test_str2 = 'geeks' 
s = set(test_str1)
s1 = set(test_str2)
if len(s) == len(s1):
    for i in s:
        if i  in s1:
            print('true')
        else:
            print('false')
            
    

    