test_str = 'GFGaBst'
def chack(string):
    s = ''
    for i in string:
        if i == 'i' or i == 'e' or i == 'a' or i == 'o' or i == 'u':
            s += ' '
        else:
            s += i
    print(s.split())
chack(test_str)
test_str = 'GFGaBstuforigeeks'
chack(test_str)