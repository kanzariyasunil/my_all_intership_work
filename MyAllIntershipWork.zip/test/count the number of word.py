test_str = 'geksefokesgergeeks'
arg_str = 'for' 
def check(string1,string2):
    wd = {}
    ws = {}

    for i in string1:
        try:
            wd[i] += 1
        except:
            wd[i] = 1
    for i in string2:
        try:
            ws[i] += 1
        except:
            ws[i] = 1

    a = float('inf')

    for i in ws.keys():
        if wd[i] < a  :
            a = wd[i] // ws[i]
    print(a)

check(test_str,arg_str)

st1 = 'thisfunhavefun'
ch1 = 'fun'
check(st1,ch1)