def chack(string):
    str_len = len(string)
    ds = ''
    for i in range(str_len):
        if i%2 == 1:
            ds += string[i]
    print(ds)

test_str = 'geekforgeeks'
chack(test_str)
test_str = 'this is a bapa sitaram group of coumpanies'
chack(test_str)