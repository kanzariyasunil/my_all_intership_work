s = 'geekksforgggeeks'
c = 1
ls = ''
b = 1
for i in s:
    if i == s[c:c+1]:
        b += 1
    else:
        b = 1
    c += 1
    ls = b
print(ls)        