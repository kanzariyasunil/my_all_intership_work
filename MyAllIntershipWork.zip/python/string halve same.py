a = 'pabctcbpta'
b = len(a) // 2
print(b)
if (len(a) % 2 == 1):
    print('this is not divide into equal')
else:
    c = sorted(a[:b])
    d = sorted(a[:-b])
    if c == d:
        print('both are same')
    else:
        print('both are not same')
    
                