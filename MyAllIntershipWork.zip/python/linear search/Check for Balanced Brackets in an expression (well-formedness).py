def brackets(string):
    stack = []
    for i in string:
        if i == '(' or i == '{' or i =='[':
            stack.append(i)
        else:
            if stack and ((stack[-1] == '(' and i == ')') or (stack[-1] == '{' and i == '}') or (stack[-1] == '[' and i == ']')):
                stack.pop()
            else:
                return False
    return not stack
    
a = '([])'
print(brackets(a))