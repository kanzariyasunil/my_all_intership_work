a = [10,20,30,40,50,70,110,130,170,200]
key = 170
def linear(lst,key):
    c = 0
    for i in lst:
        if i == key:
            print(f'the key will be found in {c}',i)
        c += 1
linear(a,key)
