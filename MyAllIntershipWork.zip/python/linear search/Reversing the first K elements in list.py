lst = [1,2,3,4,5,6,7,8,9,10]
k = 4
l = 0
for i in range(k-1):
    lst[l] = lst[k]
    l += 1
    k -= 1
print(lst)
