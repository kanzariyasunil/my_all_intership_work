a = {7,3,5,8,2,4,1,6,8,9,10}
b = {2,3,4,1}
# # add the element
# a.add(11)
# print(a)

# # update
# a.update([12,11])
# print(a)

# remove the four method
a.discard(2)
print(a)

a.remove(4)
print(a)

a.pop()
print(a)
a.pop()
print(a)

# information
print('set informaion')
print(b.isdisjoint(a))
print(a.issubset(b))
print(b.issubset(a))
print(a.issuperset(b))

# set operations
print('set opraton')
print(a.difference(b))
print(b.intersection(a))
print(a.union(b))
print(a.symmetric_difference(b))
