st = '(())()'
flag = True
count = 0

for i in st:
    if i == '(':
        count += 1
    else:
        count -= 1
if count == 0:
    print('pairing match')
else:
    print('pairing not match')