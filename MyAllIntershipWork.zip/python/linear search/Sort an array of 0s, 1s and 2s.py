a = [1,0,2,0,2,0,0,2,2,1,1]
z = a.count(0)
o = a.count(1)
t = a.count(2)
print([0]*z+[1]*o+[2]*t)
z = 0
o = 0
t = 0
for i in a:
    if i == 0:
        z += 1
    elif i == 1:
        o += 1
    else:
        t += 1

print([0]*z+[1]*o+[2]*t)