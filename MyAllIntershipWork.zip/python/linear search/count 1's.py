def count(ls):
    c = 0
    for i in ls:
        if i == 1:
            c += 1
    return c

co = [1,1,1,2,3,4,5,1,0,0,88,10]
print(count(co))