# def binary(colletion,key):
#     left = 0
#     right = len(colletion) - 1
#     while left < right:
#         mid = (left + right) // 2
#         if colletion[mid] == key:
#             print('value found')
#         if colletion[mid] < key:
#             left = mid + 1
#         else:
#             right =mid -  1
#     return 'not found'

# a = [10,20,30,40,50,60,70]
# key = 100
# print(binary(a,key))

def binary(colletion,key):
    left = 0
    right = len(colletion) - 1
    
    while left <= right:
        mid = (left + right) // 2
        if colletion[mid] == key:
            print('value found')
        if colletion[mid] < key:
            left = mid + 1
        else:
            right = mid - 1
     

a = [10,20,30,40,50,60,70]
key = 10
print(binary(a,key))
