a = [5,20,3,2,50,80]
n = 78
for i in a:
    for j in a:
        if (i + j) == n or abs(i - j) ==n:
            print('the value will be found',i,j)
