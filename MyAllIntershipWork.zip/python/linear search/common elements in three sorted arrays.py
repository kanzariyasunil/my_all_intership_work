a = {1, 5, 10, 20, 30} 
b = {5, 13, 15, 20}
c = {5, 20} 
k = set()
for i in a:
    for j in b:
        if i == j:
            k.add(i)
print(k)
for i in c:
    if i in k:
        print(i)
