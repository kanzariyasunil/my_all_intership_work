test_dict = {'Manjeet': [1], 'Akash': [8, 1, 9]} 
for idx,j in test_dict.items():
    if j not in j:
        print(j)
