ele = {1:'that',2:'this',3:'those'}
if 4 in ele:
    print(ele[4])
elif 5 in ele:
    print('vALUE of 5 will found')
else:
    print('there value is not found')

# other method is get
print(ele.get(4,'note fund 4'))
print(ele.get(7,'not fount 7'))
print(ele.get(2,'found'))

# other value is to define the usong collaction method
import collections 
dfd = collections.defaultdict(lambda :'key is not found')
dfd['a'] = 3
dfd['b'] = 4
dfd['j'] = 6
print(dfd['h'])
print(dfd['i'])

# we the the dictnary
data = {
    (1,'sr','jj'):{'a':'this is a',1:'that find'},
    (2,'hk','hd'):{'b':'this is b',2:'b is not find'},
    (3,'jio','relince'):{'m':'this is m',3:'very fine'}
}
print(data)