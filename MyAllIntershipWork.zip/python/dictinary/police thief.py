def catch(police, thief):
    building = [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]]
    police = [[],[]]
    thief = []    




# print(catch([(2,2),(8,8)], (5,5)) == (36, False))