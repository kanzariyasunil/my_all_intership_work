from operator import itemgetter
# list = [
#     {'name':'sj','age':34},
#     {'name':'hf','age':42},
#     {'name':'aa','age':12},
#     {'name':'aj','age':23},
#     {'name':'sk','age':20},
# ]
# print(sorted(list,key = itemgetter('age')))

# now merge the to dictary
dt = {1:'hii',2:'ok',3:'this',4:'fine'}
dt2 = {5:'find',6:'ok'}

def merge1(dict1,dict2):
    for i in dict2.keys():
        dict1[i] = dict2[i]
    return dict1
t = merge1(dt,dt2)
print(t)
# second way
def m(d1,d2):
    m = d1 | d2
    return m
t = m(dt,dt2)
print(t)