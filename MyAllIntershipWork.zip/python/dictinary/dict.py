# d = {1:'this is a dict1',
#      2:'this is a dict2',
#      3:'this is a dict2'}
# print(d)
# di = {1:'geeks' ,2:'for',3:'geeks'}
# di['a'] = [1,2,3,4,5,6]
# print(di)

# # many way to create dictionary
# dic = dict([(1,'geek'),(2,'greee'),(3,'green')])
# print(dic)

# # make a nested dictinary
# a = {1:'dict',2:'dict to cdict',3:{'a':'this is nested','b':'this is ','c':'dict'},'place':'nice palce'}
# print(a['place'])

# try to other way
# say = {}
# say[0] = 'hii'
# say[34] = 'ok'
# say[2] = 'try'
# print(say)
# say['value set'] = 2,3,4
# print(say)
# del say[0]
# print(say)
# print(say.items())
# print(say.keys())
# print(say.values())

# nested dictionary
dict2 ={
	'Name':
		{
			'first_name':'Steve',
			'Last_name':'Jobs'
		},
	'Age':30,
	'Designation':'Programmer',
	'address':
		{
		'Street':'Rockins Road',
		'City':'Bangalore',
		'Country':'India'
		}	 
	}

# storing the outer dictionary length 
length = len(dict2)
print(length)
# iterating to find the length
# of all inner dictionaries
for i in dict2.values():
    if isinstance(i, dict):
        length+= len(i)
    
		
print("The length of the dictionary is", length)
