def catch(police, thief):
    return (20, True)

print(catch([(2,2),(8,8)], (5,5)) == (36, False))