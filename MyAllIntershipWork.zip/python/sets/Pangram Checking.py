str = 'The quick brown fox jumps over the  '
str = str.lower()
a = 'abcdefghijklmnopqrstuvwqxyz'
c = ''
for i in a:
    if i not in str:
        c += i
print(c)        