# h ={ 1,3 ,56,8,'and','can'}
# print(h)
# b = [4,5,6,7,3,4,5,6,7,89,3,2,2,10]
# b = set(b)
# print(b)

# a = {1,2,4,2,56,3,2}
# b = {4,3,6,7,3,2,8,6,10}
# print('the missing values in a is:',a - b)
# print('the missing value is:',a.difference(b))

