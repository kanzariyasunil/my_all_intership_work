c = [12, 10, 13, 15, 8, 9]
while c:
    c.pop()
    print(c)