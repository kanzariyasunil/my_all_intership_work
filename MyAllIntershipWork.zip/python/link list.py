class node:
    def __init__(self,test):
        self.test = test
        self.no = None
        print(self.test,self.no)
d = node('this is node class')

