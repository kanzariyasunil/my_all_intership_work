test = [3,4,5,6,3,5,6,7,8,1]
co = 0
for i in test:
    for j in test:
        if test[0] == i:  
            co += 1
            break
print(co)