st = ''
st1 = 'geeks' 
st2 = 'geeksforgeeks'
s1 = 'geeks'
print('st or st1 is comapre',st or st1)
print(s1 or st1)
print(s1 and st1)
print(s1 and st2)
print(st or s1)
# the slicing step is string(start : end :steps)
j = "hii 'now i am python devloper ' "
print(j[:-5])
print(j[3:])
print(j[:5])
print(j[5],'j[5] difference beteween j[-5] ',j[-5])

