s = 'hii what are doing'
vowel = 'AaEeIiOoUu'
k = [i for i in s if i in vowel ]
print(k)