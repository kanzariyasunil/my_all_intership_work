from flask import Flask 
app = Flask(__name__)

@app.route('/')
def home():
    return 'flask will run'

@app.route('/<name>')
def name(name):
    return f'hii {name} you are learning flask'

if __name__ == '__main__':
    app.run(debug = True)
    
    
book_list = [
    
    {
        "id":1,
        "author":"manish",
        "language":"hindi",
        "title":"kaho na pyaar hai"
    },
    {
        "id":2,
        "author":"rohan",
        "language":"gujarati",
        "title":"chhelo divas"
    },
    {
        "id":3,
        "author":"allu arjun",
        "language":"tamil",
        "title":"pushpa"
    },
    {
        "id":4,
        "author":"akshay",
        "language":"hindi",
        "title":"khiladi786"
    },
    {
        "id":5,
        "author":"prabhs",
        "language":"hindi",
        "title":"bahubali"
    },
    {
        "id":6,
        "author":"ram charan",
        "language":"hindi",
        "title":"rrr"
    }
]

    