import sqlite3

conn = sqlite3.connect('title.sqlite')
cursor = conn.cursor()

sql_lite = """
create table emp(
    id int PRIMARY KEY,
    name varchar(20) not null,
    salary int not null
)
"""

cursor.execute(sql_lite)