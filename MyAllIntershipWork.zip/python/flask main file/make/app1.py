from flask import Flask,request,jsonify
import sqlite3
app = Flask(__name__)



def db_conn():
    conn = None
    try:
        conn = sqlite3.connect('title.sqlite') 
    except sqlite3.Error as e:
        print(e)
    return conn



@app.route('/')
def home():
    print('hiii')
    return '<h1>hello this is home</h1>'

@app.route('/show',methods = ["GET"])
def show():
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("select * from emp")
    data = [dict(id = row[0],name = row[1],salary = row[2]) for row in cur]
    return data

@app.route('/add',methods = ['POST'])
def add():
    conn = db_conn()
    cur = conn.cursor()
    id = request.form['id']
    name = request.form['name']
    salary = request.form['salary']
    sql = """ insert into emp (id,name,salary) values (?,?,?) """
    cur.execute(sql,(id,name,salary))
    conn.commit()
    return 'successful add'

@app.route('/update/<int:id>',methods = ['PUT'])
def update(id):
    conn = db_conn()
    cur = conn.cursor()
    sql = """ update emp set name = ?,salary = ? where id = ? """
    name = request.form['name']
    salary = request.form['salary']
    cur.execute(sql,(name,salary,id))
    conn.commit()
    return 'update succesfully'


@app.route('/delete/<int:id>',methods = ["DELETE"])
def delete(id):
    conn = db_conn()
    cur = conn.cursor()
    sql = """ delete from emp where id = ?"""
    cur.execute(sql,(id,))
    conn.commit()
    return 'deleted'



if __name__=="__main__":
    app.run(debug=True)
