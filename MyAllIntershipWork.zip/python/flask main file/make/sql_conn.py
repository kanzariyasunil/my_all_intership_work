from flask import Flask, request,session
from flask_mysqldb import MySQL
import base64 

app = Flask(__name__)


app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = ""
app.config["MYSQL_DB"] = "train"

mysql = MySQL(app)

@app.route('/')
def index():
    cur =  mysql.connect.cursor()
    cur.execute('select * from emp')
    data = cur.fetchall()
    cur.close()
    return str(data)

@app.route('/add', methods=["POST"])
def add():
    conn = mysql.connection
    cur =  conn.cursor()
    file_b64 = base64.b64encode(request.files['file_data'].read())
    cur.execute('insert into emp (id, name, salary,file_data,file_b64) values (%(id)s, %(name)s, %(salary)s,%(file_data)s,%(sunil)s) ', {"id":request.form['id'], "name":request.form["name"],"salary":request.form["salary"],"file_data":request.files["file_data"],"sunil":file_b64})
    print(cur)
    conn.commit()
    cur.close()
    return "Done"

@app.route("/update/<int:id>",methods = ['PUT'])
def update(id):
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute(" update emp set  name = %(name)s , salary = %(salary)s, where id = %(id)s",{"id":id, "name":request.form["name"],"salary":request.form["salary"]})
    print(cur)
    conn.commit()
    cur.close()
    return "done"

@app.route('/delete/<int:id>',methods = ["DELETE"])
def delete(id):
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute("delete from emp where id = %(id)s",{"id":id})
    conn.commit()
    cur.close()
    return "done"


if __name__ == "__main__":
    app.run(debug = True)







