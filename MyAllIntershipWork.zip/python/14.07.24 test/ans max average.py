nums = [1,12,-5,-6,50,3]
k = 4
l = 0
s = sum(nums[:k])
h = s
for i in nums[k:]:
    s = s + i - nums[l]
    h = max(s, h)
    l += 1
print(h/4)