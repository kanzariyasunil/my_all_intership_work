p = [4,3,2,1]
left = 0
right = 1
ans = 0
while right < (len(p)):
    if p[right] < p[left]:
        left = right
    else:
        ans = max(p[right]-p[left],ans)
    right += 1
print(ans)       