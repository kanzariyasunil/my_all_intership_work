a = [1,2,3,3,2,1,3,4,5,5,3,5,6,4,3]
# a = set(a)
# print(len(a))
b = []
# other way is 
for i in a:
    if i not in b:
        b.append(i)
print(b)