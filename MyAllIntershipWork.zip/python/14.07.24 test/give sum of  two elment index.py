def index(list1,target):
    for i in range(len(list1)):
        for j in range(i+1,len(list1)):
            if list1[i] + list1[j] == target:
                print('the index is ',i,j)
                return i,j 
                    

nums = [2,7,11,15]
target = 9
index(nums,target)
nums = [2,3,4,1,6,4,5]
target = 8
index(nums,target)  
