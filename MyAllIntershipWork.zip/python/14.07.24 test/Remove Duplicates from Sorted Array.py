def remove(list):
    i = 0
    a = []
    while i < len(list):
        if list[i] not in a:
            a.append(list[i])
        i += 1
    return a
nums = [0,0,1,1,1,2,2,3,3,4]

print(remove(nums))
nums = [2,3,2,1,3,4,5,3,4,5,56,67,5,3,2,3,5,100,4,2,12,4,53,]
print(remove(nums))
