arr = [1, 1, 1, 1, 1]
a = 0
b = []
for i in arr:
    a += i
    b.append(a)
print(b)
	