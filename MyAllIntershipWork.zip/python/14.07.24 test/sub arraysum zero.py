a= [4,2,-3,1,6]
l = 0
r = len(a) - 1
while l < r:
    if sum(a[l:r]) == 0:
        print(a[l],a[r])
    elif sum(a[l:r]) > 0 and a[l] > a[r]:
        l += 1
    elif     