a = [6,1,3,4, 3, 5]
def abc(a):
    c = 0
    for i in range(len(a)-1):
        if a[i] > a[i+1]:
            c += 1
            if c == 2:
                return False
    if a[0] > a[-1]: 
        return True
    else:
        return False
    
print(abc(a))
print(abc([2,1,3,4]))
# print(a[0],a[l])
# if a[0] > a[l] and c == 1:
#     print('array are sorted')
# else:
#     print(False)
