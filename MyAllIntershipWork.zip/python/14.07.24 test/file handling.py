import io
# text io
f = open('test.txt','r',encoding = 'utf-8')
f = io.StringIO('this is some intinal data')
print(f)

# binary io
b = open('test.txt','rb')
b = io.BytesIO(b'some data print here\x00\x01' )
print(b)

# raw io
