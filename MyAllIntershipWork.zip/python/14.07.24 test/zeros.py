nums = [40,0,0,0,4,3,0,5,0,2,1,0]
n = 0
z = 0
while n < len(nums) and z < len(nums):
    if nums[z] != 0:
        z += 1
        continue
    if n > z:
        if nums[n] != 0:
            nums[z] = nums[n]
            nums[n] = 0
            z += 1
    n+=1

print(nums)