class student:
    def __init__(self,name,rollno,m1,m2):
        self.name = name
        self.rollno = rollno
        self.m1 = m1
        self.m2 = m2
        
    def accept(self,name,rollno,m1,m2):
        ob = student(name,rollno,m1,m2)
        ls.append(ob)
    
    def display(self,ob):
        print('name:',ob.name,'rollno:',ob.rollno,'m1:',ob.m1,'m2:',ob.m2)
        
    def serch(self,rn):
        for i in range(ls.__len__()):
            if (ls[i].rollno == rn):
                return i
    
    def delete(self,rn):
        i = obj.serch(rn)
        del ls[i]
    
    def update(self,rn,no):
        i = obj.serch(rn)
        rollno = no
        ls[i].rollno = rollno
        
ls = []
obj = student('',0,0,0)

obj.accept('sachin',1,90,95)
obj.accept('saurav',2,91,96)
obj.accept('rahul',3,92,97)
obj.accept('karan',4,93,98)
obj.accept('sumit',5,94,99)

# obj.display(ls[0])
obj.display(ls[1])

print('delete method\n')

obj.delete(2)
for i in range(ls.__len__()):
    obj.display(ls[i])

print('update method\n')
    
obj.update(3,10)
for i in range(ls.__len__()):
    obj.display(ls[i])
    
    