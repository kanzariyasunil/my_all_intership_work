class flashcard:
    def __init__(self):
        self.fruit = {
            'apple':'red',
            'banana':'yellow',
            'chiku':'brown',
            'grapes':'green',
        }
        
    def quiz(self):
        print('Welcome to quiz ')
        score = 0
        
        for i in self.fruit:
            print('what is color of ',i)
            ans =input('enter the name of color :')
            
            if ans == self.fruit[i]:
                score+=1
                print('correct')
            else:
                print('wrong')

        print('your score is ',score)

flash = flashcard()
flash.quiz()