class empty_class:
    def empty(self):
        pass
    
emp = empty_class()

emp.name = 'abc'
emp.office = 'xyz'
print(emp.name,emp.office)

emp1 = empty_class()
emp1.name = 'pqr'
emp1.office = 'mno'
emp1.price = 4235243

print(emp1.name,emp1.office,emp1.price)