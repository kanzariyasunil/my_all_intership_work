print('aaba'.split('b'))
l = []
l.append('aa')
l.append('a')
print(l)