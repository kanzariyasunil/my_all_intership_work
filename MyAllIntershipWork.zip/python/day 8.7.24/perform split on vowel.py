test = 'GFGaBstejhgfioobvcnmx'
a = 'AEIOUaeiou'
prev = ''
ans = []
for i in test:
        if i.lower() == 'i' or i.lower() == 'e' or i.lower() == 'a' or i.lower() == 'o' or i.lower() == 'u':
                if len(prev):
                        ans.append(prev)
                        prev = ''
        else:
                prev += i
print(ans)