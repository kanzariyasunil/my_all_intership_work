string = "GeeksforGeeks A  portal computer science portal for  portal geeks"
word = "portal"
st = string.split(" ")
x = 0
for i in st:
    if word == i:
        x += 1
print(x)