h = 'hello el'
d = 1
v = ''
for i in h:
    if i in h[d:]:
        v += i
    d += 1
print(v)