# s = 'geeks for geeks'
# s1 = 'geeks'
    
# if (s1 in s):
#     print('the string is match')

# other function use 
h = [23,44,26,34,67,26,39,51]
v = list(filter(lambda x: x%13==0,h))
print(v)

k = filter(lambda x : x%13 == 0,h)
print(k)

# apply all list to palindrom 
d = ['hih','hoo','geeks','gees','keek']
k = list(filter(lambda x: x == x[::-1],d))
j = list(filter(lambda x: x == "".join(reversed(x)),d))
print(k)
print(j)
