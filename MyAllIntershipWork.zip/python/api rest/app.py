from flask import Flask,render_template,request
from flask_mysqldb import MySQL
app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'ayurvedik'

mysql = MySQL(app)


@app.route('/')
def hello():
    return render_template('index.html')

@app.route("/product_man",methods = ['GET'])
def product_man():
    cur = mysql.connect.cursor()
    cur.execute('select * from product_man')
    data = cur.fetchall()
    cur.close()
    return str(data)

@app.route("/product_add",methods = ['POST'])
def product_add():
    conn = mysql.connection
    cur = conn.cursor()
    data = cur.execute("insert into product_man (product_id,product_name,product_price) values (%(product_id)s,%(product_name)s,%(product_price)s)",{"product_id":request.form['product_id'],"product_name":request.form['product_name'],"product_price":request.form['product_price']})
    conn.commit()
    cur.close()
    return "new product will add {}".format(data)

@app.route("/product_update/<int:id>",methods=["PUT"])
def product_update(id):
    conn = mysql.connection
    cur = conn.cursor()
    data = cur.execute('update product_man set product_name = %(product_name)s,product_price = %(product_price)s where product_id = %(id)s',{"id":id,"product_name":request.form['product_name'],"product_price":request.form['product_price']})
    conn.commit()
    cur.close()
    return 'product will be updated {}'.format(data)

@app.route("/product_delete/<int:id>",methods = ["DELETE"])
def product_delete(id):
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute('delete from product_man where product_id = %(id)s',{"id":id})
    conn.commit()
    cur.close()
    return "deleted successfully one row"

# start a costumer table

@app.route("/customer",methods = ['GET'])
def costomer():
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute("select * from customer")
    data = cur.fetchall()
    cur.close()
    return str(data)

@app.route("/customer_add",methods = ["POST"])
def customer_add():
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute("insert into customer(customer_id,customer_name,buy_product,quantity) values (%(customer_id)s,%(customer_name)s,%(buy_product)s,%(quantity)s)",{"customer_id":request.form["customer_id"],"customer_name":request.form["customer_name"],"buy_product":request.form["buy_product"],"quantity":request.form["quantity"]})
    conn.commit()
    cur.close()
    return " customer id wil be added successfully"

@app.route("/customer_update/<int:id>",methods = ["PUT"])
def customer_update(id):
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute('update customer set customer_name = %(customer_name)s,buy_product = %(buy_product)s,quantity = %(quantity)s where customer_id = %(customer_id)s',{"customer_id":request.form['customer_id'],"customer_name":request.form["customer_name"],"buy_product":request.form["buy_product"],"quantity":request.form["quantity"]})
    conn.commit()
    cur.close()
    return "customer columns update success"

@app.route("/customer_delete/<int:id>", methods =["DELETE"])
def customer_delete(id):
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute("delete from customer where customer_id = %(customer_id)s",{"customer_id":id})
    conn.commit()
    cur.close()
    return "delete the id"

@app.route("/soup")
def buyer():
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute("select c.customer_name,c.buy_product,c.quantity,p.product_price from customer c inner join product_man p on p.product_name= c.buy_product where c.buy_product ='soup' ")
    data = cur.fetchall()
    cur.close()
    return str(data)


if __name__ == "__main__":
    app.run(debug =True)
    