def ThreeSum(list):
    list = sorted(list)
    l = 0
    r = len(list) - 1
    add = []
    for i in range(len(list)):
        l = i +1
        
        while l < r:
            if list[i] + list[l] + list[r] == 0:
                add.append([list[i],list[l],list[r]])
                l +=1 
                r -= 1
            elif list[i] + list[l] + list[r] < 0:
                l += 1
            else:
                r -=1 
    return add            
print(ThreeSum([1,23,3,4,2,-4,-7,-4,-1,3,-4,-1,-2]))