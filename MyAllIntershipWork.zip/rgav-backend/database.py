from dotenv import load_dotenv
import psycopg2
from psycopg2 import extras
import os
from typing import List,Optional,Tuple,Union,Any
load_dotenv()

conn = None
def set_cursor():
    """
    This function sets up a cursor connection to our PostgreSQL database.

    It does this by:
    1. Retrieving the necessary credentials from the environment variables.
    These environment variables are expected to be set up in a .env file,
    which is automatically loaded by the `load_dotenv()` function.
    2. Using the retrieved credentials to establish a connection to the
    PostgreSQL database.
    3. Returning a cursor object, which allows us to execute SQL queries
    on the database.
    """
    
    # Setting up the global connection object.
    # This is necessary because the `conn` variable is used in the 
    # `make_db_call` function.
    global conn 
    
    # Establishing a connection to the database.
    # The `psycopg2.connect()` function takes in the necessary credentials
    # (username, password, host, database, port) to connect to the database.
    # These credentials are retrieved from the environment variables.
    conn = psycopg2.connect(
        user = os.environ.get('USER'),  # Retrieving username from environment variable
        password = os.environ.get('PASSWORD'),  # Retrieving password from environment variable
        host = os.environ.get('HOST'),  # Retrieving host from environment variable
        database = os.environ.get('DATABASE'),  # Retrieving database from environment variable
        port = os.environ.get('PORT')  # Retrieving port from environment variable
    )
    
    # Returning a cursor object, which allows us to execute SQL queries on the database.
    return conn.cursor()  # The `cursor()` method returns a cursor object for the connection.

def make_db_call(query:str , type :Optional[str] ,parameter:Optional[List[Any]]) -> Union[List[Tuple[Any]],bool]:
    cur = set_cursor()

    try:
        cur.execute(query,parameter)
        conn.commit()

        if type == "returns":
            try:
                data = cur.fetchall()
            except Exception as e:
                data = [[None]]
            if not data:
                data = [[None]]
            cur.close()
            return data
        else:
            cur.close()
            return True
    except Exception as e:
        cur.execute("ROLLBACK")
        conn.commit()
        cur.close()
        raise e or ValueError("could not platform query")


def make_many_db_call(query:str , type :Optional[str] ,parameter:Optional[List[Any]]) -> Union[List[Tuple[Any]],bool]:
    cur = set_cursor()

    try:
        extras.execute_values(cur,query,parameter)
        conn.commit()

        if type == "returns":
            try:
                data = cur.fetchall()
            except Exception as e:
                data = [[None]]
            if not data:
                data = [[None]]
            cur.close()
            return data
        else:
            cur.close()
            return True
    except Exception as e:
        cur.execute("ROLLBACK")
        conn.commit()
        cur.close()
        raise e or ValueError("could not platform query")

