import datetime
from flask import Blueprint,request
from dotenv import load_dotenv
load_dotenv()
import os,json,base64
from database import make_db_call, make_many_db_call


blueprint = Blueprint('orders',__name__)

file_path = os.environ.get('QUERY_PATH') + "orders.json"

try:
    if os.path.exists(file_path):
        with open(file_path,'r') as file:
            queries = json.load(file)
    else:
        print('file is not exists')
except:
    print('error occuerd file path')
   

@blueprint.route('/order',methods=['POST'])
def order(): 
    prod_instock = make_db_call(
        query = queries['check_instock'].replace('##id##',str('%s') + ', %s'*(len(request.json['product'])-1)),
        type='returns',parameter=[prod[0] for prod in request.json['product']])
    
    order_id = make_db_call(query= queries['insert_order'],
                                 type = 'returns',
                                 parameter = {
                                     "user_email":request.json['user_email'],
                                     "shipping_address":request.json['shipping_address'],
                                     "order_total":request.json['order_total'],
                                     "order_date":datetime.datetime.now(),
                                     "order_status":1,
                                     "order_tax":request.json['order_tax'],
                                     "coupon_code":request.json['coupon_code'],
                                     "discount":request.json['discount']
                                 }    )[0][0]
    make_db_call(query= queries['order_table'].replace('##name##',order_id),type = '',parameter={})
    
    data = make_many_db_call(query=queries['insert_order_table'].replace('##name##',order_id),type = 'returns',
                              parameter=request.json['product'])
    
    for i in range(len(prod_instock)):
        for j in range(len(data)):
            if prod_instock[i][0] == data[j][0]:
                if 0 < prod_instock[i][1] - data[j][1]:
                    diff = prod_instock[i][1] - data[j][1]
                    print(diff,data[i][0])
                    make_db_call(query=queries['update_product'],type='',parameter={"product_instock":diff,"product_id":prod_instock[i][0]})
                else:
                    return prod_instock[i][0] + "out of stock"
                
    return "done"

@blueprint.route('/get_order',methods=['GET','POST'])
def get_order():
    data = make_db_call(query=queries['get_order_id'],type='returns',parameter={"phone":request.args.get('phone')})
    
        
    data1 = make_db_call(query=queries['orders'].replace('##name##',str(data[0][0])),type='returns',parameter={})
    response = []
    for i in range(len(data1)):
        product_name = make_db_call(query= queries['product_name'],type = 'returns',parameter= {'product_id':data1[i][0]}) 
        response.append(
            {   "product_name":product_name[i-1][0],
                "product_price":product_name[i-1][1],
                "order_id":data[0][0],
                "username":data[0][1],
                "user_email":data[0][2],
                "phone":data[0][3],
                "total_price":data[0][4],
                "order_status":data[0][5],
                "quentity":data[0][6],
                "coupon_code":data[0][7],
                "expected_date":data[0][8],
                "product_img":''
            }
        )  
    try:
        file_path = os.environ.get('IMG_PATH')
        for product in response:
            file_path_with_name = os.path.join(file_path, product['product_name'], '0.jpg')
            if os.path.isfile(file_path_with_name):
                with open(file_path_with_name, mode="rb") as file:
                    product['product_img'] = base64.b64encode(file.read()).decode('utf-8')
    except Exception as e:
        print(f"Error: {e}")
    return response
