from datetime import datetime
from flask import Flask,render_template,flash,redirect,url_for
from form import RegisterForm,LoginForm
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)

app.config['SECRET_KEY'] = 'c89f7f127a2d9426f969bfb251b1d15e'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)



posts = [
    
{
    'author':'corey',
    'title':'blog',
    'content':'first blog',
    'date':'10-3-2020'
},
{
    'author':'aroy',
    'title':'blog 2',
    'content':'third blog',
    'date':'10-3-2022'
},
{
    'author':'abhay',
    'title':'page',
    'content':'make blog',
    'date':'10-3-2023'
}
]
@app.route('/')
def home():
    return render_template('index.html',posts = posts)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/register',methods = ['GET','POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        flash(f'Account are created {form.username.data}!','success')
        return redirect(url_for('home'))
    return render_template('register.html',title = 'register',form = form)

@app.route('/login')
def login():
    form = LoginForm()
    return render_template('login.html',title ='login',form = form)


if __name__ == '__main__':
    app.run(debug = True)
